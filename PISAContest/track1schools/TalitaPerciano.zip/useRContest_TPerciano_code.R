###### useR PISA contest 2014
###### Talita Perciano
###### Daniela Ushizima
###### Lawrence Berkeley National Laboratory
###### 06/29/2014

# License: Creative Common BY&SA license

require(plyr)
require(ggplot2)
require(ggmap)
require(memisc)
require(wq)


#require(ENmisc)
#require(cwhmisc)
#require(grid)
#require(maps)
#require(quantreg)

setwd('/Users/tperciano/Dropbox/Artigos/RConference2014/Contest')

### Functions (some from package 'intsvy' with some modifications) ###

pisa.mean <-
function(variable, by, data, export=FALSE, name= "output", folder=getwd()) {
    mean.input <- function(variable, data) {
        meanrp <-     achmrp <- sapply(1:80, function(i) weighted.mean(as.numeric(unlist(data[,variable])),
        rep(data[[paste("W_FSTR", i , sep="")]],length(variable)), na.rm = TRUE))
        
        meantot <- weighted.mean(as.numeric(unlist(data[,variable])), rep(data[["W_FSTUWT"]],length(variable)), na.rm = TRUE)
        meanse <- (0.05*sum((meanrp-meantot)^2))^(1/2)
        result <- data.frame("Freq"=sum(!is.na(data[,variable])), "Mean"= meantot, "Std.err."= meanse)
        return(round(result, 2))
    }
    if (missing(by)) {
        output <- mean.input(variable=variable, data=data)
    } else {
        for (i in by) {
            data[[c(i)]] <- as.character(data[[c(i)]])
        }
        output <- ddply(data, by, function(x) mean.input(data=x, variable=variable))
    }
    
    if (export)  {
        write.csv(output, file=file.path(folder, paste(name, ".csv", sep="")))
    }
    
    return(output)
}

pisa.table <-
function(variable, by, data, export=FALSE, name= "output", folder=getwd()) {
    table.input <- function(variable, data) {
        
        if (sum(is.na((data[[variable]])))==length(data[[variable]])) {
            result <- data.frame(NA, "Freq"=0, "Percentage"=NA, "Std.err."= NA)
            names(result)[1] <- variable
            return(result)
        }
        
        # Sampling error)
        tabrp <- as.matrix(sapply(1:80, function(i) percent(as.factor(as.numeric(data[[variable]])), total=FALSE,
        weights=  data[[paste("W_FSTR", i , sep="")]], na.rm=TRUE)))
        
        # Total weighted %
        tabtot <- percent(as.factor(as.numeric(data[[variable]])), weights= data[["W_FSTUWT"]], na.rm = TRUE, total=F)
        # Standard error
        if (length(tabtot)!=1) {
            tabse <- (0.05*apply((tabrp-tabtot)^2, 1, sum))^(1/2)
        }
        else {
            tabse <-0
        }
        result <- data.frame(table(data[[variable]][drop=T]), "Percentage"=round(as.numeric(tabtot), 2), "Std.err."= round(tabse, 2))
        names(result)[1] <- variable # var label for table, otherwise prints "Var1"
        return(result)
    }
    if (missing(by)) {
        output <- table.input(variable=variable, data=data)
    } else {
        for (i in by) {
            data[[c(i)]] <- as.character(data[[c(i)]])
        }
        output <- ddply(data, by, function(x) table.input(data=x, variable=variable))
    }
    
    if (export)  {
        write.csv(output, file=file.path(folder, paste(name, ".csv", sep="")))
    }
    
    return(output)
}

pisa.select.merge <-
function(folder=getwd(), student.file, parent.file=c(), school.file=c(), countries, student=c(), parent, school) {
    
    # Remove leading and trailing whitespaces in var labes
    if(!missing(student) & !is.null(student)) {
        student = gsub("^[[:space:]]+|[[:space:]]+$", "", student)
        student =toupper(student)
    }
    
    if(!missing(parent)){
        parent = gsub("^[[:space:]]+|[[:space:]]+$", "", parent)
        parent = toupper(parent)
    }
    
    if(!missing(school)){
        school = gsub("^[[:space:]]+|[[:space:]]+$", "", school)
        school = toupper(school)
    }
    
    # No variables selected (error)
    
    if (missing(student) & missing(parent) & missing(school)) {
        stop("no variables are selected")
    }
    
    # Creating student, parent, and school filepaths
    
    # Student file required for country labels
    if(missing(student.file)) {
        stop("the student file is required")
    }
    
    if(!missing(folder) & !missing(student.file)) {
        student.file =   file.path(folder, paste(student.file, sep=""))
    }
    
    if(!missing(folder) & !missing(school.file)) {
        school.file =  file.path(folder, paste(school.file, sep=""))
    }
    
    if(!missing(folder) & !missing(parent.file)) {
        parent.file =  file.path(folder, paste(parent.file, sep=""))
    }
    
    # Retrieve file names
    files.all <- list(student.file, parent.file, school.file)
    names(files.all) <- c('Student', 'Parent', 'School')
    
    # Remove null elements in list
    files.all <- files.all[lapply(files.all, length)>0]
    
    # Participating countries (from student file)
    pisa.student_name <- load(files.all[["Student"]])
    pisa.student <- get(pisa.student_name[[1]])
    rm(list = unlist(pisa.student_name))
    country <- names(table(pisa.student[,"CNT"]))
    
    # If countries missing, all countries selected
    if (missing(countries)) {
        countries <- country
    }
    
    # If countries are entered numerically, change to ISO labels for file selection (next)
    if (is.numeric(countries)) {
        countries=pisa.country[pisa.country$Code %in% countries, "ISO"]
    }
    
    
    # Student data (need for school and parent data too)
    
    if (!missing(student) | !missing(parent)) {
        
        names(pisa.student) <- toupper(names(pisa.student)) # because stidstd is lowercase sometimes
        
        student.data <- pisa.student[countries %in% unlist(pisa.student["CNT"]),
        c("CNT", "SCHOOLID", "STIDSTD",names(pisa.student)[grep("^PV", names(pisa.student))], student, names(pisa.student)[grep("^W_F", names(pisa.student))],
        "W_FSTUWT")]
        
        student.data <- as.data.frame(student.data)
        
    }
    
    
    # Parental questionnaire
    
    if (!missing(parent)) {
        
        if (is.null(files.all[["Parent"]])) {
            stop("cannot locate parental questionnaire data file")
        }
        
        pisa.parent_name <- load(files.all[["Parent"]])
        pisa.parent <- get(pisa.parent_name[[1]])
        rm(list = unlist(pisa.parent_name))
        names(pisa.parent) <- toupper(names(pisa.parent))
        
        parent.data <- pisa.parent[countries %in% unlist(pisa.parent["CNT"]),
        c("CNT", "SCHOOLID", "STIDSTD", parent)]
        
        parent.data <- as.data.frame(parent.data)
    }
    
    
    # School data
    
    if (!missing(school)) {
        
        if (is.null(files.all[["School"]])) {
            stop("cannot locate school data file")
        }
        
        pisa.school_name <- load(files.all[["School"]])
        pisa.school <- get(pisa.school_name[[1]])
        rm(list = unlist(pisa.school_name))
        names(pisa.school) <- toupper(names(pisa.school))
        
        school.data <- pisa.school[countries %in% unlist(pisa.school["CNT"]),
        c("CNT", "OECD", "SCHOOLID", school, "W_FSCHWT")]
        
        school.data <- as.data.frame(school.data)
        
    }
    
    
    # Merging data depending on existing datasets/arguments
    
    # Student data available
    
    if (!missing(student) & missing(parent) & missing(school)) {
        pisa.all <- student.data
    }
    
    if (!missing(student) & !missing(parent) & missing(school)) {
        pisa.all <- merge(student.data, parent.data, all.x=TRUE, by=c("CNT", "SCHOOLID", "STIDSTD"))
        pisa.all[, grep("*.y", names(pisa.all))] <- NULL
        names(pisa.all) <- gsub("*.x", "", names(pisa.all))
    }
    
    if (!missing(student) & missing(parent) & !missing(school)) {
        pisa.all <- merge(student.data, school.data, all.x=TRUE, by=c("CNT", "SCHOOLID"))
        pisa.all[, grep("*.y", names(pisa.all))] <- NULL
        names(pisa.all) <- gsub("*.x", "", names(pisa.all))
    }
    
    if (!missing(student) & !missing(parent) & !missing(school)) {
        pisa.all <- merge(student.data, parent.data, all.x=TRUE, by=c("CNT", "SCHOOLID", "STIDSTD"))
        pisa.all <- merge(pisa.all, school.data, all.x=TRUE, by=c("CNT", "SCHOOLID"))
        pisa.all[, grep("*.y", names(pisa.all))] <- NULL
        names(pisa.all) <- gsub("*.x", "", names(pisa.all))
    }
    
    # Parent data available
    
    if (is.null(student) & !missing(parent) & missing(school)) {
        pisa.all <- merge(student.data, parent.data, by=c("CNT", "SCHOOLID", "STIDSTD"))
        pisa.all[, grep("*.y", names(pisa.all))] <- NULL
        names(pisa.all) <- gsub("*.x", "", names(pisa.all))
    }
    
    if (is.null(student) & !missing(parent) & !missing(school)) {
        pisa.all <- merge(school.data, parent.data, by=c("CNT", "SCHOOLID"))
        pisa.all[, grep("*.y", names(pisa.all))] <- NULL
        names(pisa.all) <- gsub("*.x", "", names(pisa.all))
    }
    
    # School data available
    
    if (is.null(student) & missing(parent) & !missing(school)) {
        pisa.all <- school.data
    }
    
    # Create country label variable (not possible to add labels to numeric factor, see to do list)
    
    return(pisa.all)
}

pisa.mean.school <- function(variable, by, data, export=FALSE, name= "output", folder=getwd()) {
    mean.input <- function(variable, data) {
        # Total weighted mean
        meantot <- weighted.mean(as.numeric(unlist(data[,variable])), rep(data[["W_FSCHWT"]],length(variable)), na.rm = TRUE)
        result <- data.frame("Freq"=sum(!is.na(data[,variable])), "Mean"= meantot)
        return(round(result, 2))
    }
    if (missing(by)) {
        output <- mean.input(variable=variable, data=data)
    } else {
        for (i in by) {
            data[[c(i)]] <- as.character(data[[c(i)]])
        }
        output <- ddply(data, by, function(x) mean.input(data=x, variable=variable))
    }
    
    if (export)  {
        write.csv(output, file=file.path(folder, paste(name, ".csv", sep="")))
    }
    
    return(output)
}

pisa.table.school <- function(variable, by, data, export=FALSE, name= "output", folder=getwd()) {
    table.input <- function(variable, data) {
        
        if (sum(is.na((data[[variable]])))==length(data[[variable]])) {
            result <- data.frame(NA, "Freq"=0, "Percentage"=NA, "Std.err."= NA)
            names(result)[1] <- variable # var label for table, otherwise prints "Var1"
            return(result)
        }
        
        # Total weighted %
        tabtot <- percent(as.factor(as.numeric(data[[variable]])), weights= data[["W_FSCHWT"]], na.rm = FALSE, total=F)
        result <- data.frame(table(data[[variable]][drop=T]), "Percentage"=round(as.numeric(tabtot), 2))
        names(result)[1] <- variable # var label for table, otherwise prints "Var1"
        return(result)
    }
    # If by not supplied, calculate for complete sample
    if (missing(by)) {
        output <- table.input(variable=variable, data=data)
    } else {
        # Convert by variables to characters for ddply application
        for (i in by) {
            data[[c(i)]] <- as.character(data[[c(i)]])
        }
        output <- ddply(data, by, function(x) table.input(data=x, variable=variable))
    }
    
    if (export)  {
        write.csv(output, file=file.path(folder, paste(name, ".csv", sep="")))
    }
    
    return(output)
}



## Define names of the database files and selected variables for analysis

student.file = 'student2012.rda'
parent.file  = 'parent2012.rda'
school.file  = 'school2012.rda'
load(student.file)
load(school.file)
student      = c('ST08Q01','ST09Q01','ST11Q01','ST48Q01','ST87Q03','ST87Q04','ST87Q06','ST87Q07','ST87Q08','ST87Q09','IC02Q01','IC02Q02','IC02Q03','IC02Q04','IC02Q05',
'IC02Q06','IC02Q07','IC05Q01','IC10Q02','IC10Q03','IC10Q04','IC10Q05','IC10Q06','IC10Q07','IC10Q08','IC10Q09','EC03Q04','ATSCHL','ATTLNACT','BELONG','EXAPPLM','EXPUREM',
'ICTATTNEG','ICTATTPOS','ICTSCH','USESCH')
parent       = c('PQSCHOOL','PA09Q01','PA09Q02','PA09Q03','PA09Q04','PA09Q05','PA09Q06','PA09Q07','PA12Q02','PA12Q05','PA12Q07','PA12Q08','PA12Q09','PA12Q10','PA12Q11','PARINVOL')
school       = c('SC02Q01','SC02Q02','SC02Q03','SC02Q04','SC03Q01','SC05Q01','SC09Q11','SC09Q12','SC13Q01','SC13Q02','SC13Q03','CLSIZE','COMPWEB')
school       = c(school,'CREACTIV','PROPCERT','RESPCUR','RESPRES','SCHAUTON','SCHLTYPE','SCHSEL','SCHSIZE','SCMATBUI','SCMATEDU','STRATIO','STUDCLIM','TCFOCST','TCHPARTI','TCMORALE','TCSHORT','TEACCLIM')
pisa.complete = pisa.select.merge(student.file = student.file,parent.file=parent.file,school.file=school.file,student=student,parent=parent,school=school)

# Take care of the wrong NAs in OECD variable for student database
# Some of the countries has NAs mixtures with the right OECD group
for (i in 1:length(levels(pisa.complete$CNT))) {
	country = levels(pisa.complete$CNT)[i]
	index1 = which(pisa.complete$CNT==country)
	oecdvalues = pisa.complete$OECD[index1]
	index2 = which(is.na(oecdvalues))
	if (length(index2)<length(oecdvalues)) {
		pisa.complete$OECD[index1] = pisa.complete$OECD[index1[1]]
	}
}

# Create variable 'Main Funding' which is the group of main source funding
index = which(school2012$SC02Q01>66.3)
school2012[['MainFunding']] = rep(NA,nrow(school2012))
school2012$MainFunding[index] = 'Government'
index = which(school2012$SC02Q02>66.3)
school2012$MainFunding[index] = 'StudentFees'
index = which(school2012$SC02Q03>66.3)
school2012$MainFunding[index] = 'Benefactors'
index = which(school2012$SC02Q04>66.3)
school2012$MainFunding[index] = 'Other'
school2012$MainFunding = as.factor(school2012$MainFunding)

# Get the names of the countries in database
countries <- names(table(student2012[,"CNT"]))

rm(student2012)

# Add 'Main Funding' variable to school database
tempdata <- school2012[countries %in% unlist(school2012["CNT"]), c("CNT", "SCHOOLID", "MainFunding")]
tempdata <- as.data.frame(tempdata)
pisa.complete <- merge(pisa.complete, tempdata, all.x=TRUE, by=c("CNT", "SCHOOLID"))
pisa.complete[, grep("*.y", names(pisa.complete))] <- NULL
names(pisa.complete) <- gsub("*.x", "", names(pisa.complete))


# Calculate total mean performance by country
# Considers PV1MATH, PV1READ and PV1SCIE
vars = c('PV1MATH','PV1READ','PV1SCIE')
total_mean_bycountry = pisa.mean(vars,by="CNT",data = pisa.complete)

# Calculate total mean performance by OECD
# Considers PV1MATH, PV1READ and PV1SCIE
total_mean_byoecd = pisa.mean(vars,by="OECD",data = pisa.complete)

# Order by general mean
total_mean_bycountry_ordered = total_mean_bycountry[with(total_mean_bycountry,order(-Mean, CNT)),]

# Add general mean performance to student database
pisa.complete2 = merge(pisa.complete,total_mean_bycountry,by=c("CNT"))
rm(pisa.complete)

# Settings for the boxplot graphic
control1 <<- levels(pisa.complete2$CNT)
control2 <<- 1
my_mean = function(x) {
	str(x)
	country = control1[control2]
	index = which(pisa.complete2$CNT==country)
	w = pisa.complete2$W_FSTUWT[index]
	str(w)
	control2 <<- control2 + 1
	if (control2>length(control1)) {
		control2 <<- 1
	}
	return(weighted.mean(x,w))
}

orderedcnt_ = reorder(pisa.complete2$CNT,(pisa.complete2$PV1MATH+pisa.complete2$PV1READ+pisa.complete2$PV1SCIE)/3,FUN=my_mean)
orderedcnt = rev(levels(orderedcnt_))
orderedcnt_abb = abbreviate(orderedcnt,minlength=8)
orderedcnt_labels = list()
colors1 = c()
for (i in 1:length(orderedcnt)) {
	index = which(total_mean_bycountry_ordered$CNT==orderedcnt[i])
	orderedcnt_labels[[i]] = paste(orderedcnt_abb[[i]],' (',total_mean_bycountry_ordered$Mean[index],')',sep='')
	index = which(pisa.complete2$CNT==orderedcnt[i])
	if (!is.na(pisa.complete2$OECD[index[1]])) {
		if (pisa.complete2$OECD[index[1]]=='OECD') {
			colors1[i] = 'darkblue'
		}
		else
        colors1[i] = 'darkgreen'
	} else
    colors1[i] = 'darkred'
}

title = "General Mean Performance of the Students per Country considering PV1MATH, PV1READ and PV1SCIE"


boxplot = ggplot(pisa.complete2,aes(x=orderedcnt_,y=(PV1MATH+PV1READ+PV1SCIE)/3,weight=W_FSTUWT))
boxplot = boxplot + geom_boxplot(outlier.shape=NA,notch=T,width=0.7,alpha=0.7,aes_string(colour="Std.err.",fill="Std.err."))
boxplot = boxplot + scale_x_discrete(labels=rev(unlist(orderedcnt_labels)))
total_mean_bycountry_ordered = total_mean_bycountry[with(total_mean_bycountry,order(-Mean, CNT)),]
index = which(total_mean_bycountry_ordered$Mean<total_mean_byoecd$Mean[2])
cut = length(total_mean_bycountry_ordered$CNT)-index[1]+1.5
boxplot = boxplot + geom_vline(xintercept=cut,color='darkred')
boxplot = boxplot + geom_text(aes(x=cut, label="\nOECD Mean", y=100), colour='darkred', size=3)
boxplot = boxplot + theme(axis.text.y = element_text(colour = rev(colors1)),legend.position="top")
boxplot = boxplot +  coord_flip() + ggtitle("") + xlab("") + ylab("Analysis of general performance")
#boxplot

# Settings for worldmap graphic
row.names(total_mean_bycountry_ordered) = seq(1:68)

colors = c()
for (i in 1:length(orderedcnt)) {
	index = which(pisa.complete2$CNT==orderedcnt[i])
	if (!is.na(pisa.complete2$OECD[index[1]])) {
		if (pisa.complete2$OECD[index[1]]=='OECD') {
			colors[i] = 'OECD'
		}
		else
        colors[i] = 'Non-OECD'
	} else {
		colors[i] = 'NA'
	}
}

index_below = which(total_mean_bycountry_ordered$Mean<total_mean_byoecd$Mean[2])
index_above = which(total_mean_bycountry_ordered$Mean>=total_mean_byoecd$Mean[2])
total_mean_bycountry_ordered[['From_OECD_Mean']] = rep(NA,68)
total_mean_bycountry_ordered$From_OECD_Mean[index_below] = 'Below'
total_mean_bycountry_ordered$From_OECD_Mean[index_above] = 'Above'

#Get world map info
map.world <- map_data("world")

loc =  geocode(total_mean_bycountry_ordered$CNT)
total_mean_bycountry_ordered[['lon']] = loc$lon
total_mean_bycountry_ordered[['lat']] = loc$lat

p <- ggplot() + coord_fixed()
base_world <- p + geom_polygon(data=map.world,aes(x=long,y=lat,group=group),alpha=0.9)

geo_data <- data.frame(CNT=orderedcnt,
long=total_mean_bycountry_ordered$lon,
lat=total_mean_bycountry_ordered$lat,
Performance=total_mean_bycountry_ordered$Mean,
OECD=colors,
From_OECD_Mean=total_mean_bycountry_ordered$From_OECD_Mean)

map_with_jitter <- base_world+geom_point(data=geo_data,
aes(x=long,
y=lat,
colour=OECD,
size=Performance,shape=From_OECD_Mean),
position="jitter",
alpha=I(0.6))


map_with_jitter <- map_with_jitter + ggtitle(title) + ylab("") + xlab('Longitude') + scale_y_continuous(breaks=c(),labels=c())


# Now, analysis of the 5 best and 5 worst countries by general performance

# Calculate general performance mean for each school
df_list = list()
for (i in 1:length(countries)) {
	index = which(pisa.complete2$CNT==countries[i])
	df_list[[i]] = pisa.complete2[index,]
}

df_list_means = list()
for (i in 1:length(df_list)) {
	df_list_means[[i]] = pisa.mean(vars,data = df_list[[i]],by='SCHOOLID')
}

schoolmeans = data.frame(Mean=df_list_means[[1]]$Mean,Std.err.=df_list_means[[1]]$Std.err.)
for (i in 2:length(countries)) {
	if (i!=52 & i!=53 & i!=54) {
		schoolmeans = rbind(schoolmeans,df_list_means[[i]][,3:4])
	}
}

# Add mean values to school database
school2012$Mean = schoolmeans$Mean
school2012$Std.err. = schoolmeans$Std.err.


# Obtain top5 and worst5 countries
top5countries = orderedcnt[1:5]

for (i in 1:length(top5countries)) {
	index = which(school2012$CNT==top5countries[i])
	if (i==1) {
		school.top5 = school2012[index,]
	}
	else {
		school.top5 = rbind(school.top5,school2012[index,])
	}
}

for (i in 1:length(top5countries)) {
	index = which(pisa.complete2$CNT==top5countries[i])
	if (i==1) {
		pisa.top5 = pisa.complete2[index,]
	}
	else {
		pisa.top5 = rbind(pisa.top5,pisa.complete2[index,])
	}
}


worst5countries = orderedcnt[64:68]

for (i in 1:length(worst5countries)) {
	index = which(school2012$CNT==worst5countries[i])
	if (i==1) {
		school.worst5 = school2012[index,]
	}
	else {
		school.worst5 = rbind(school.worst5,school2012[index,])
	}
}

for (i in 1:length(worst5countries)) {
	index = which(pisa.complete2$CNT==worst5countries[i])
	if (i==1) {
		pisa.worst5 = pisa.complete2[index,]
	}
	else {
		pisa.worst5 = rbind(pisa.worst5,pisa.complete2[index,])
	}
}

# Some statistics for school variables
tabletop5.SC03Q01 = pisa.table.school('SC03Q01',data=school.top5)
top5.meanbySC03Q01 = pisa.mean.school('Mean',data=school.top5,by='SC03Q01')
tableworst5.SC03Q01 = pisa.table.school('SC03Q01',data=school.worst5)
worst5.meanbySC03Q01 = pisa.mean.school('Mean',data=school.worst5,by='SC03Q01')

# SC03Q01 pie graphic
data_SC03Q01_perc = rbind(tabletop5.SC03Q01,tableworst5.SC03Q01)
data_SC03Q01_perc[['Group']] = c(rep('Best 5 countries',5),rep('Worst 5 countries',5))
data_SC03Q01_perc = ddply(data_SC03Q01_perc, .(Group), transform, pos = cumsum(Percentage)-0.5*Percentage)
means = c()
for (i in 1:nrow(data_SC03Q01_perc)) {
	means[i] = top5.meanbySC03Q01$Mean[i]
}
for (i in 6:nrow(data_SC03Q01_perc)) {
	means[i] = worst5.meanbySC03Q01$Mean[i-5]
}
data_SC03Q01_perc[['Mean']] = means

pie_SC03Q01 = ggplot(data_SC03Q01_perc, aes(x = factor(1)  ,y = Percentage ,fill = factor(SC03Q01)),)
pie_SC03Q01 = pie_SC03Q01 + geom_bar(width=1,stat='identity')
pie_SC03Q01 = pie_SC03Q01 + facet_grid(facets=. ~ Group)
pie_SC03Q01 = pie_SC03Q01 + coord_polar(theta="y") + theme(plot.title = element_text(size = 10))
pie_SC03Q01 = pie_SC03Q01 + xlab('' ) + ylab('') + labs(fill='Type of city') + ggtitle('Amount of schools in each type of city \n(labels are the total mean values of performance)')
pie_SC03Q01 = pie_SC03Q01 + geom_text(aes(x = c(1,1.2,1,1,1,1,1,1,1,1),y=data_SC03Q01_perc$pos,label=round(Mean,digits=1)),size=3)
pie_SC03Q01 = pie_SC03Q01 + theme(legend.position="bottom")
#pie_SC03Q01


tabletop5.CREACTIV = pisa.table.school('CREACTIV',data=school.top5)
top5.meanbyCREACTIV = pisa.mean.school('Mean',data=school.top5,by='CREACTIV')
tableworst5.CREACTIV = pisa.table.school('CREACTIV',data=school.worst5)
worst5.meanbyCREACTIV = pisa.mean.school('Mean',data=school.worst5,by='CREACTIV')

# CREACTIV pie graphic

data_CREACTIV_perc = rbind(tabletop5.CREACTIV,tableworst5.CREACTIV)
data_CREACTIV_perc[['Group']] = c(rep('Best 5 countries',4),rep('Worst 5 countries',4))
data_CREACTIV_perc = ddply(data_CREACTIV_perc, .(Group), transform, pos = cumsum(Percentage)-0.5*Percentage)
means = c()
for (i in 1:nrow(data_CREACTIV_perc)) {
	means[i] = top5.meanbyCREACTIV$Mean[i]
}
for (i in 5:nrow(data_CREACTIV_perc)) {
	means[i] = worst5.meanbyCREACTIV$Mean[i-4]
}
data_CREACTIV_perc[['Mean']] = means

pie_CREACTIV = ggplot(data_CREACTIV_perc, aes(x = factor(1)  ,y = Percentage ,fill = factor(CREACTIV)),)
pie_CREACTIV = pie_CREACTIV + geom_bar(width=1,stat='identity')
pie_CREACTIV = pie_CREACTIV + facet_grid(facets=. ~ Group)
pie_CREACTIV = pie_CREACTIV + coord_polar(theta="y")+ theme(plot.title = element_text(size = 10))
pie_CREACTIV = pie_CREACTIV + xlab('' ) + ylab('') + labs(fill='Number of activities') + ggtitle('Extracurricular activities at school \n(labels are the total mean values of performance)')
pie_CREACTIV = pie_CREACTIV + geom_text(aes(x = factor(1),y=data_CREACTIV_perc$pos,label=round(Mean,digits=1)),size=3)
pie_CREACTIV = pie_CREACTIV + theme(legend.position="bottom")
#pie_CREACTIV


tabletop5.SCHLTYPE = pisa.table.school('SCHLTYPE',data=school.top5)
top5.meanbySCHLTYPE = pisa.mean.school('Mean',data=school.top5,by='SCHLTYPE')
tableworst5.SCHLTYPE = pisa.table.school('SCHLTYPE',data=school.worst5)
worst5.meanbySCHLTYPE = pisa.mean.school('Mean',data=school.worst5,by='SCHLTYPE')

# SCHLTYPE pie graphic

data_SCHLTYPE_perc = rbind(tabletop5.SCHLTYPE,tableworst5.SCHLTYPE)
data_SCHLTYPE_perc[['Group']] = c(rep('Best 5 countries',3),rep('Worst 5 countries',3))
data_SCHLTYPE_perc = ddply(data_SCHLTYPE_perc, .(Group), transform, pos = cumsum(Percentage)-0.5*Percentage)
means = c()
for (i in 1:nrow(data_SCHLTYPE_perc)) {
	means[i] = top5.meanbySCHLTYPE$Mean[i]
}
for (i in 4:nrow(data_SCHLTYPE_perc)) {
	means[i] = worst5.meanbySCHLTYPE$Mean[i-3]
}
data_SCHLTYPE_perc[['Mean']] = means
labels_schtype = c(rep(c('Private Independent','Private gov-dependent','Public'),2))
data_SCHLTYPE_perc$SCHLTYPE = labels_schtype

pie_SCHLTYPE = ggplot(data_SCHLTYPE_perc, aes(x = factor(1)  ,y = Percentage ,fill = factor(SCHLTYPE)),)
pie_SCHLTYPE = pie_SCHLTYPE + geom_bar(width=1,stat='identity')
pie_SCHLTYPE = pie_SCHLTYPE + facet_grid(facets=. ~ Group)
pie_SCHLTYPE = pie_SCHLTYPE + coord_polar(theta="y")+ theme(plot.title = element_text(size = 10))
pie_SCHLTYPE = pie_SCHLTYPE + xlab('' ) + ylab('') + labs(fill='Type of school') + ggtitle('Type of school \n(labels are the total mean values of performance)')
pie_SCHLTYPE = pie_SCHLTYPE + geom_text(aes(x = factor(1),y=data_SCHLTYPE_perc$pos,label=round(Mean,digits=1)),size=3)
pie_SCHLTYPE = pie_SCHLTYPE + theme(legend.position="bottom")
#pie_SCHLTYPE


tabletop5.MainFunding = pisa.table.school('MainFunding',data=school.top5)
tabletop5.MainFunding = data.frame(MainFunding=rep(NA,4),Freq=rep(NA,4),Percentage=rep(NA,4))
tabletop5.MainFunding$MainFunding = as.factor(c('Benefactors','Government','Other','StudentFees'))
tabletop5.MainFunding$Freq = c(0,578,0,51)
tabletop5.MainFunding$Percentage = c(0,92.95,0,7.05)
top5.meanbyMainFunding = pisa.mean.school('Mean',data=school.top5,by='MainFunding')
top5.meanbyMainFunding = data.frame(MainFunding=rep(NA,4),Freq=rep(NA,4),Mean=rep(NA,4))
top5.meanbyMainFunding$MainFunding = as.factor(c('Benefactors','Government','Other','StudentFees'))
top5.meanbyMainFunding$Freq = c(0,54138,0,4716)
top5.meanbyMainFunding$Mean = c(0,535.00,0,565.69)
tableworst5.MainFunding = pisa.table.school('MainFunding',data=school.worst5)
worst5.meanbyMainFunding = pisa.mean.school('Mean',data=school.worst5,by='MainFunding')

# Main funding pie graphic

data_MainFunding_perc = rbind(tabletop5.MainFunding,tableworst5.MainFunding)
data_MainFunding_perc[['Group']] = c(rep('Best 5 countries',4),rep('Worst 5 countries',4))
data_MainFunding_perc = ddply(data_MainFunding_perc, .(Group), transform, pos = cumsum(Percentage)-0.5*Percentage)
means = c()
for (i in 1:nrow(data_MainFunding_perc)) {
	means[i] = top5.meanbyMainFunding$Mean[i]
}
for (i in 5:nrow(data_MainFunding_perc)) {
	means[i] = worst5.meanbyMainFunding$Mean[i-4]
}
data_MainFunding_perc[['Mean']] = means

pie_MainFunding = ggplot(data_MainFunding_perc, aes(x = factor(1)  ,y = Percentage ,fill = factor(MainFunding)),)
pie_MainFunding = pie_MainFunding + geom_bar(width=1,stat='identity')
pie_MainFunding = pie_MainFunding + facet_grid(facets=. ~ Group)
pie_MainFunding = pie_MainFunding + coord_polar(theta="y")+ theme(plot.title = element_text(size = 10))
pie_MainFunding = pie_MainFunding + xlab('' ) + ylab('') + labs(fill='Source of Funding') + ggtitle('Source of Funding \n(labels are the total mean values of performance)')
pie_MainFunding = pie_MainFunding + geom_text(aes(x = c(1,1,1,1.2,1,1,1,1),y=data_MainFunding_perc$pos,label=round(Mean,digits=1)),size=3)
pie_MainFunding = pie_MainFunding + theme(legend.position="bottom")
#pie_MainFunding




meantop5.SCMATBUI = pisa.mean.school('SCMATBUI',data=school.top5)   #Quality of physical infrastructure    OK
meanworst5.SCMATBUI = pisa.mean.school('SCMATBUI',data=school.worst5)
meantop5.SCMATEDU = pisa.mean.school('SCMATEDU',data=school.top5)  #Quality of school educational resources   OK
meanworst5.SCMATEDU = pisa.mean.school('SCMATEDU',data=school.worst5)
meantop5.TCFOCST = pisa.mean.school('TCFOCST',data=school.top5)    #Teacher focus
meanworst5.TCFOCST = pisa.mean.school('TCFOCST',data=school.worst5)
meantop5.TCHPARTI = pisa.mean.school('TCHPARTI',data=school.top5)    #Teacher participation/autonomy
meanworst5.TCHPARTI = pisa.mean.school('TCHPARTI',data=school.worst5)
meantop5.TCSHORT = pisa.mean.school('TCSHORT',data=school.top5)            #Shortage of teaching Staff   OK
meanworst5.TCSHORT = pisa.mean.school('TCSHORT',data=school.worst5)

# Other school factors graphic

OtherSchoolFactors = c('Quality Physical Infras.','Quality School Educ. Resources','Teacher focus','Teacher participation','Shortage of Teach. Staff')

data_OtherSchoolFactors = data.frame(Factors = rep(OtherSchoolFactors,2))
data_OtherSchoolFactors[['Group']] = c(rep('Best 5 countries',5),rep('Worst 5 countries',5))
data_OtherSchoolFactors[['Index']] = c(meantop5.SCMATBUI$Mean+1.10,meantop5.SCMATEDU$Mean+1.10,-meantop5.TCFOCST$Mean+1.10,-meantop5.TCHPARTI$Mean+1.10,meantop5.TCSHORT$Mean+1.10,meanworst5.SCMATBUI$Mean+1.10,meanworst5.SCMATEDU$Mean+1.10,-meanworst5.TCFOCST$Mean+1.10,-meanworst5.TCHPARTI$Mean+1.10,meanworst5.TCSHORT$Mean+1.10)


pie_OtherSchoolFactors = ggplot(data_OtherSchoolFactors, aes(x = factor(1)  ,y = Index ,fill = factor(Factors)),)
pie_OtherSchoolFactors = pie_OtherSchoolFactors + geom_bar(width=1,stat='identity')
pie_OtherSchoolFactors = pie_OtherSchoolFactors + facet_grid(facets=. ~ Group)+ theme(plot.title = element_text(size = 10))
pie_OtherSchoolFactors = pie_OtherSchoolFactors + xlab('' ) + ylab('') + labs(fill='Factor') + ggtitle('Other school factors')
#pie_OtherSchoolFactors

# Build total set of graphics

png('useRContest_TPerciano_teste.png',width=26.66667,height=15,units='in',res=400)
theme = theme_set(theme_minimal())
layOut(list(map_with_jitter, 1:2, 1:4),list(pie_MainFunding, 3, 2),list(pie_SCHLTYPE, 3,3),list(pie_SC03Q01, 4,2),list(pie_CREACTIV,4,3),list(pie_OtherSchoolFactors,3,4),list(boxplot,1:4,1))
dev.off()


