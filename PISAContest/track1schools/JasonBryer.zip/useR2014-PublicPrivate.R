# Install the required R packages
install.packages(c('devtools','ggplot2','psych'), repos='http://cran.r-project.org')
devtools::install_github('jbryer/multilevelPS')

# Set to the directory containing this R script. Assumes the PISA Rda files
# are in a data subdirectory.
setwd("~/Dropbox/Projects/pisa2012")

require(ggplot2)
require(psych)
require(multilevelPSA)

data(pisa.countries)
load('data/student2012dict.rda')
load('data/student2012.rda')
load('data/school2012.rda')
if(file.exists('PISA2012.SchoolType.Rda')) {
	# Cached file. Saved below.
	load('PISA2012.SchoolType.Rda')
}

psa.cols <- names(student2012dict)[substr(names(student2012dict), 1, 4) %in% 
								   	c('ST01','ST04','ST06','ST07','ST08','ST09',
								   	  'ST11','ST13','ST17','ST18','ST20','ST26',
								   	  'ST27','ST28','ST29','ST37','ST55','ST57','ST61')]

# These are the covariates that will be used to estimate the propensity scores.
student2012dict[names(student2012dict) %in% psa.cols]

# Subset the data frames
student <- student2012[,c('CNT', 'SCHOOLID',
						   paste0('PV', 1:5, 'MATH'),
						   paste0('PV', 1:5, 'READ'),
						   paste0('PV', 1:5, 'SCIE'),
						   psa.cols)]
school <- school2012[,c("CNT", "SCHOOLID",
						 "SCHLTYPE" #Public (3)
						            #Private independent (1)
						            #Private government dependent (2)
)]

school$CNT <- as.character(school$CNT)
student$CNT <- as.character(student$CNT)
student <- merge(pisa.countries, student, by.x='Country', by.y='CNT', all.y=TRUE)

# Countries not in pisa.countires
unique(student[is.na(student$CNT3),]$Country)
student[student$Country == 'China-Shanghai',]$CNT3 <- 'CHN2'
student[student$Country == 'Costa Rica',]$CNT3 <- 'CRI'
student[student$Country == 'Malaysia',]$CNT3 <- 'MYS'
student[student$Country == 'Perm(Russian Federation)',]$CNT3 <- 'RUS'
student[student$Country == 'United Arab Emirates',]$CNT3 <- 'UAE'
student[student$Country == 'United States of America',]$CNT3 <- 'USA'
student[student$Country == 'Connecticut (USA)',]$CNT3 <- 'USA'
student[student$Country == 'Massachusetts (USA)',]$CNT3 <- 'USA'
student[student$Country == 'Florida (USA)',]$CNT3 <- 'USA'
student[student$Country == 'Vietnam',]$CNT3 <- 'VNM'

stopifnot(nrow(student[is.na(student$CNT3),]) == 0)

# Cross-tab of private and public schools. For the purposes here, we will combine
# both types of privates schools.
table(school$SCHLTYPE, useNA='ifany')
school$SchoolType <- ifelse(school$SCHLTYPE == 3, 'Public', 'Private')
table(school$CNT, school$SchoolType, useNA='ifany')

# Merge in school type
student <- merge(student, school, by.x=c('Country','SCHOOLID'), 
				 by.y=c('CNT','SCHOOLID'), all.x=TRUE)

# Remove students that don't have a school type
student <- student[!is.na(student$SchoolType),]
table(student$CNT3, student$SchoolType, useNA='ifany')

# Remove students in countries with no private or public school students
tab <- as.data.frame(table(student$CNT3, student$SchoolType))
student <- student[-which(student$CNT3 %in% tab[tab$Freq == 0,]$Var1),]

student$CNT3 <- as.factor(student$CNT3)
student$SchoolType <- factor(student$SchoolType, levels=c('Public','Private'))

# Estimate the propensity scores using conditional inference trees
mlctree <- mlpsa.ctree(student[,c('CNT3','SchoolType',psa.cols)], 
					   formula=SchoolType ~ ., level2='CNT3')
student.party <- getStrata(mlctree, student, level2='CNT3')

pisa.colnames <- data.frame(Variable=names(student2012dict), 
							ShortDesc=student2012dict,
							stringsAsFactors=FALSE)

#Tree heat map showing relative importance of covariates used in each tree.
tree.plot(mlctree, level2Col=student$CNT3, colLabels=pisa.colnames[,c('Variable','ShortDesc')])

#Balance plot (here for completeness, not part of the submitted graphic)
# cv.bal <- covariate.balance(covariates=student[,psa.cols],
# 							treatment=student$SchoolType,
# 							level2=student$CNT3,
# 							strata=student.party$strata)
# plot(cv.bal)

# Perform the multilevel PSA
results.psa.math <- mlpsa(response=student.party$PV1MATH,
						  treatment=student.party$SchoolType,
						  strata=student.party$strata,
						  level2=student.party$CNT3, minN=5)
results.psa.read <- mlpsa(response=student.party$PV1READ,
						  treatment=student.party$SchoolType,
						  strata=student.party$strata,
						  level2=student.party$CNT3, minN=5)
results.psa.scie <- mlpsa(response=student.party$PV1SCIE,
						  treatment=student.party$SchoolType,
						  strata=student.party$strata,
						  level2=student.party$CNT3, minN=5)

p.math <- mlpsa.circ.plot(results.psa.math) + ggtitle('Mathematics')
p.math.diff <- mlpsa.difference.plot(results.psa.math, sd=mean(student.party$PV1MATH, na.rm=TRUE))
p.read <- mlpsa.circ.plot(results.psa.read) + ggtitle('Reading')
p.read.diff <- mlpsa.difference.plot(results.psa.read, sd=mean(student.party$PV1READ, na.rm=TRUE))
p.scie <- mlpsa.circ.plot(results.psa.scie) + ggtitle('Science')
p.scie.diff <- mlpsa.difference.plot(results.psa.scie, sd=mean(student.party$PV1SCIE, na.rm=TRUE))
 
png('PISA2012/PISA2012PrivatePublic.png', width=2048, height=1152, units='px')
grid_layout = grid.layout(nrow=2, ncol=3, respect=TRUE)
grid.newpage()
pushViewport( viewport( layout=grid_layout ) )
multilevelPSA:::align.plots(grid_layout,
							list(p.math + theme(legend.position='none'), 1, 1), 
							list(p.math.diff + theme(legend.position='none'), 2, 1),
							list(p.read + theme(legend.position='none'), 1, 2), 
							list(p.read.diff + theme(legend.position='none'), 2, 2),
							list(p.scie + theme(legend.position='none'), 1, 3), 
							list(p.scie.diff + theme(legend.position='none'), 2, 3))
dev.off()

# Numeric results
summary(results.psa.math)
summary(results.psa.read)
summary(results.psa.scie)

results.psa.math$overall.wtd
# Save data file with all the analysis
save(mlctree, student.party, student, school, psa.cols, pisa.colnames,
	 results.psa.math, file='PISA2012.SchoolType.Rda')
