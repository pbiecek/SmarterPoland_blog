# a script for UseR!2014 data visualization contest, by Yasuto NAKANO
## 29/Jun/2014
#####################
# inequality between/within countries
## This scatter plot visualizes a relationship between mean mathematics score of each countries and Gini index of the score within each countries, attached with childrens' motivation.
## The plot tells us that there are inequalitiy between countries(= there are differences between county means). Furthermore there are inequality within each countries(= there are non-zero Gini indes score for each countries) and deprived(low scored) countries tend to have high inner inequality(high Gini index).
## And yet, childrens motivations are relatively high in deprived/inequal countries.
## This graph is about MATH, but READ and SCIE are also the case.


load("student2012.rda")
names(student2012)

library(ggplot2)
source("http://aoki2.si.gunma-u.ac.jp/R/src/Gini_index.R", encoding="euc-jp")

by(student2012$PV1MATH,student2012$CNT,Gini.index) -> gini.pv1math
by(student2012$PV1MATH,student2012$CNT,mean) -> mean.pv1math
factor(student2012$ST29Q02,levels=c("Strongly disagree","Disagree","Agree","Strongly agree"))->ST29Q02.rev
by(as.numeric(ST29Q02.rev),student2012$CNT,mean,na.rm=TRUE) -> mean.st29q02
data.frame(cnt=names(gini.pv1math),gini=unlist(as.list(gini.pv1math)),mean=unlist(as.list(mean.pv1math)),motivation=unlist(as.list(mean.st29q02))) -> data
q <- ggplot(data, aes(x=mean, y=gini, label=cnt))
q <- q + geom_text(aes(colour=motivation),size=2)+labs(x="mean of PV1MATH by countries",y="Gini index of PV1MATH",title="Inequalities between/within countries \n and average motivations")+scale_colour_gradient(low='green',high='red')
print(q)
ggsave("datavisualizationcontest2014.01.png",q)


#by(student2012$PV1READ,student2012$CNT,Gini.index) -> gini.pv1read
#by(student2012$PV1READ,student2012$CNT,mean) -> mean.pv1read
#factor(student2012$ST29Q02,levels=c("Strongly disagree","Disagree","Agree","Strongly agree"))->ST29Q02.rev
#by(as.numeric(ST29Q02.rev),student2012$CNT,mean,na.rm=TRUE) -> mean.st29q02
#data.frame(cnt=names(gini.pv1read),gini=unlist(as.list(gini.pv1read)),mean=unlist(as.list(mean.pv1read)),motivation=unlist(as.list(mean.st29q02))) -> data
#q <- ggplot(data, aes(x=mean, y=gini, label=cnt))
#q <- q + geom_text(aes(colour=motivation),size=2)+labs(x="mean of PV1READ by countries",y="Gini index of PV1READ",title="Inequalities between/within countries \n and average motivations")+scale_colour_gradient(low='green',high='red')
#print(q)


#by(student2012$PV1SCIE,student2012$CNT,Gini.index) -> gini.pv1scie
#by(student2012$PV1SCIE,student2012$CNT,mean) -> mean.pv1scie
#factor(student2012$ST29Q02,levels=c("Strongly disagree","Disagree","Agree","Strongly agree"))->ST29Q02.rev
#by(as.numeric(ST29Q02.rev),student2012$CNT,mean,na.rm=TRUE) -> mean.st29q02
#data.frame(cnt=names(gini.pv1scie),gini=unlist(as.list(gini.pv1scie)),mean=unlist(as.list(mean.pv1scie)),motivation=unlist(as.list(mean.st29q02))) -> data
#q <- ggplot(data, aes(x=mean, y=gini, label=cnt))
#q <- q + geom_text(aes(colour=motivation),size=2)+labs(x="mean of PV1SCIE by countries",y="Gini index of PV1SCIE",title="Inequalities between/within countries \n and average motivations")+scale_colour_gradient(low='green',high='red')
#print(q)
