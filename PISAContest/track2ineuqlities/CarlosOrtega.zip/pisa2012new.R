#------------------------------------------------
# Date: 2014-06
# Author: Carlos Ortega (cof@qualityexcellence.es) - Spain - Madrid 
# Purpose: Analyze PISA values of 2012
#
# Input: Data available in .rda format
# Output: Different charts exported to png (HD).
#
#------------------------------------------------


#Libraries
library(HH)
library(ggplot2)
library(lattice)
library(latticeExtra)
library(gridExtra)
library(dplyr)
library(reshape2)
library(sqldf)

#------------------------
# STUDENT DATA
#------------------------
stud.con <- url("http://beta.icm.edu.pl/PISAcontest/data/student2012.rda")
load(stud.con)
studdict.con <- url("http://beta.icm.edu.pl/PISAcontest/data/student2012dict.rda")
load(studdict.con)

# Reframe dictionary
student.dict.df <- data.frame(Var=names(student2012dict), Desc=student2012dict)
rownames(student.dict.df) <- NULL
#head(student.dict.df,10)

## Define colors
library(RColorBrewer)
#display.brewer.all()

myColours <- brewer.pal(9,"Paired") #9 es el máximo de colores.
#display.brewer.pal(9, "Paired")

my.settings <- list(
  superpose.polygon=list(col=myColours[1:6], border="transparent"),
  strip.background=list(col=myColours[6]),
  strip.border=list(col="black")
)

my.settings.two <- list(
  superpose.polygon=list(col=myColours[c(2,4,6)], border="yellow", lwd=2)
  ,strip.background=list(col=myColours[6])
  ,strip.border=list(col="black")
  ,background=list(col="white")
  ,axis.line=list(col="black", lwd=2)
  ,superpose.symbol=list(col=myColours[c(2,4,6)], pch=16)
  ,plot.symbol=list(pch=16, col=myColours[c(2,4,6)], fill=myColours[c(2,4,6)])
)


# Reference: http://smarterpoland.pl/index.php/2014/05/do-you-like-datavis-and-want-to-win-1400-during-user-2014-conference/
#------------------------- STUDENT - SCORES ALL COUNTRIES ---------------------
#--- Math, Reading and Science values (PV1MATH - PV1READ - PV1SCIE) by Country (COUNTRY)
mathScores <- unclass(by(student2012[,c("PV1MATH", "W_FSTUWT")], 
                         student2012$CNT,
                         function(x) weighted.mean(x[,1], x[,2])) )

readScores <- unclass(by(student2012[,c("PV1READ", "W_FSTUWT")], 
                         student2012$CNT,
                         function(x) weighted.mean(x[,1], x[,2])) )

sciScores <- unclass(by(student2012[,c("PV1SCIE", "W_FSTUWT")], 
                         student2012$CNT,
                         function(x) weighted.mean(x[,1], x[,2])) )



# create a data.frame with scores and country names
# remove names with (in name) they are subcountries/states/provinces
readmathscieScores <- data.frame(Country=names(readScores), readScores, mathScores, sciScores)
readmathscieScores <- readmathscieScores[-grep(readmathscieScores$Country, pattern="(", fixed=TRUE),]
rownames(readmathscieScores) <- NULL

#Get countries sorted
remasco.sort <- sqldf("select * from readmathscieScores order by readScores")
remasco.sort$Country <- factor(remasco.sort$Country, levels=remasco.sort$Country, ordered=TRUE)

# Sort it to "dotplot"...
remaSco.df <- melt(readmathscieScores, id.vars='Country', measure.vars=c('readScores','mathScores','sciScores')
                   ,variable.name='remath', value.name='score')
remaSco.df$Country <- factor(remaSco.df$Country, levels=remasco.sort$Country, ordered=T)
#head(remaSco.df)

One.gr <- dotplot(
         Country ~ score
        ,data=remaSco.df
        ,groups=remath
        ,auto.key = list(
                          levels(remaSco.df$remath), space = "top", columns=3
                         ,fill=myColours[c(2,4,6)], col=myColours[c(2,4,6)] 
                         )
        ,xlab =list("Read - Math - Science scores", col="blue", cex=1.3, font=2)
        ,ylab=NULL
        ,par.settings = my.settings.two
        ,scales=list(cex=0.7, font=2, col="black")
        )  


#Top-10 Countries
remaSco.df10 <- remaSco.df[remaSco.df$Country %in% tail(remasco.sort$Country,10), ]

Oneone.gr <- dotplot(
  Country ~ score
  ,data=remaSco.df10
  ,groups=remath
        ,auto.key = list(
                          levels(remaSco.df$remath), space = "top", columns=3
                         ,fill=myColours[c(2,4,6)], col=myColours[c(2,4,6)] 
                         )
  ,main="COUNTRY SCORING - TOP 10 (sorted by Reading)"
        ,xlab =list("Read - Math - Science scores", col="blue", cex=1.3, font=2)
        ,ylab=NULL
        ,par.settings = my.settings.two
        ,scales=list(cex=0.9, font=2, col="black")
)  

#--------------------------
# By considering Gender
#--------------------------

#------------------------- STUDENT - SCORES ALL COUNTRIES ---------------------
#--- Math, Reading and Science values (PV1MATH - PV1READ - PV1SCIE) by Country (COUNTRY)
#--- MALE
stu.male <- student2012[student2012$ST04Q01=="Male",]

mathScoresmale <- unclass(by(stu.male[,c("PV1MATH", "W_FSTUWT")], 
                         stu.male$CNT,
                         function(x) weighted.mean(x[,1], x[,2])) )

readScoresmale <- unclass(by(stu.male[,c("PV1READ", "W_FSTUWT")], 
                         stu.male$CNT,
                         function(x) weighted.mean(x[,1], x[,2])) )

sciScoresmale <- unclass(by(stu.male[,c("PV1SCIE", "W_FSTUWT")], 
                        stu.male$CNT,
                        function(x) weighted.mean(x[,1], x[,2])) )



remasciScomal <- data.frame(Country=names(readScores), readScoresmale, mathScoresmale, sciScoresmale)
remasciScomal <- remasciScomal[-grep(remasciScomal$Country, pattern="(", fixed=TRUE),]
rownames(remasciScomal) <- NULL


#Get countries sorted
remascomal.sort <- sqldf("select * from remasciScomal order by readScoresmale")
remascomal.sort$Country <- factor(remascomal.sort$Country, levels=remascomal.sort$Country, ordered=TRUE)

# Sort it to "dotplot"...
remaScomale.df <- melt(remasciScomal, id.vars='Country', measure.vars=c('readScoresmale','mathScoresmale','sciScoresmale')
                   ,variable.name='remath', value.name='score')
remaScomale.df$Country <- factor(remaScomale.df$Country, levels=remascomal.sort$Country, ordered=T)
#head(remaScomale.df)

dotplot(
  Country ~ score
  ,data=remaScomale.df
  ,groups=remath
        ,auto.key = list(
                          levels(remaScomale.df$remath), space = "top", columns=3
                         ,fill=myColours[c(2,4,6)], col=myColours[c(2,4,6)] 
                         )
  ,main="MALE SCORING"
        ,xlab =list("Read - Math - Science scores", col="blue", cex=1.3, font=2)
        ,ylab=NULL
        ,par.settings = my.settings.two
        ,scales=list(cex=0.9, font=2, col="black")
  
)  

#Top-10 Male
remaScomale.df10 <- remaScomale.df[remaScomale.df$Country %in% tail(remascomal.sort$Country,10), ]

male.gr <- dotplot(
  Country ~ score
  ,data=remaScomale.df10
  ,groups=remath
        ,auto.key = list(
                          levels(remaScomale.df10$remath), space = "top", columns=3
                         ,fill=myColours[c(2,4,6)], col=myColours[c(2,4,6)] 
                         )
  ,main="MALE SCORING - TOP 10 (sorted by Reading)"
        ,xlab =list("Read - Math - Science scores", col="blue", cex=1.3, font=2)
        ,ylab=NULL
        ,par.settings = my.settings.two
        ,scales=list(cex=0.9, font=2, col="black")
)  




#------------------------- STUDENT - SCORES ALL COUNTRIES ---------------------
#--- Math, Reading and Science values (PV1MATH - PV1READ - PV1SCIE) by Country (COUNTRY)
#--- FEMALE
stu.female <- student2012[student2012$ST04Q01=="Female",]

mathScoresfemale <- unclass(by(stu.female[,c("PV1MATH", "W_FSTUWT")], 
                             stu.female$CNT,
                             function(x) weighted.mean(x[,1], x[,2])) )

readScoresfemale <- unclass(by(stu.female[,c("PV1READ", "W_FSTUWT")], 
                             stu.female$CNT,
                             function(x) weighted.mean(x[,1], x[,2])) )

sciScoresfemale <- unclass(by(stu.female[,c("PV1SCIE", "W_FSTUWT")], 
                            stu.female$CNT,
                            function(x) weighted.mean(x[,1], x[,2])) )



remasciScofem <- data.frame(Country=names(readScores), readScoresfemale, mathScoresfemale, sciScoresfemale)
remasciScofem <- remasciScofem[-grep(remasciScofem$Country, pattern="(", fixed=TRUE),]
rownames(remasciScofem) <- NULL


#Get countries sorted
remascofem.sort <- sqldf("select * from remasciScofem order by readScoresfemale")
remascofem.sort$Country <- factor(remascofem.sort$Country, levels=remascofem.sort$Country, ordered=TRUE)

# Sort it to "dotplot"...
remaScofemale.df <- melt(remasciScofem, id.vars='Country', measure.vars=c('readScoresfemale','mathScoresfemale','sciScoresfemale')
                       ,variable.name='remath', value.name='score')
remaScofemale.df$Country <- factor(remaScofemale.df$Country, levels=remascofem.sort$Country, ordered=T)
#head(remaScofemale.df)

dotplot(
  Country ~ score
  ,data=remaScofemale.df
  ,groups=remath
        ,auto.key = list(
                          levels(remaScofemale.df$remath), space = "top", columns=3
                         ,fill=myColours[c(2,4,6)], col=myColours[c(2,4,6)] 
                         )
  ,main="FEMALE SCORING"
        ,xlab =list("Read - Math - Science scores", col="blue", cex=1.3, font=2)
        ,ylab=NULL
        ,par.settings = my.settings.two
        ,scales=list(cex=0.9, font=2, col="black")
)  

#Top-10
remaScofemale.df10 <- remaScofemale.df[remaScofemale.df$Country %in% tail(remascofem.sort$Country,10), ]

female.gr <- dotplot(
  Country ~ score
  ,data=remaScofemale.df10
  ,groups=remath
        ,auto.key = list(
                          levels(remaScofemale.df10$remath), space = "top", columns=3
                         ,fill=myColours[c(2,4,6)], col=myColours[c(2,4,6)] 
                         )
  ,main="FEMALE SCORING - TOP 10 (sorted by Reading)"
        ,xlab =list("Read - Math - Science scores", col="blue", cex=1.3, font=2)
        ,ylab=NULL
        ,par.settings = my.settings.two
        ,scales=list(cex=0.9, font=2, col="black")
)  


#----------------------------------------------------------------------------------------
#------------------------- STUDENT - LEARNING TIMES - ALL COUNTRIES ---------------------
#--- Math, Reading and Science Learning Times  (LMINS - MMINS - SMINS) by Country (COUNTRY)
# Result: MMINS, LMINS, SMINS (Learning times have a lot of NA's)
# Linear regression with weights.

# Math
coutimmat.df <- student2012[, c("CNT", "PV1MATH", "MMINS", "W_FSTUWT")]
coutimmat.df <- coutimmat.df[-grep(coutimmat.df$CNT, pattern="(", fixed=TRUE),]

xyplot(
   PV1MATH ~ MMINS | CNT 
  ,data=coutimmat.df
  ,xlab = "Minutes of study"
  ,ylab="PV1MATH"
  ,main="MATH"
  ,layout=c(4,4)
  ,scales="free"  
  ,as.table=TRUE
)  

#Top-10
coun10.top <- as.vector(unique(remaSco.df10$Country))
coutimmat.df10 <- coutimmat.df[coutimmat.df$CNT %in% coun10.top, ]
coutimmat.df10$CNT <- factor(coutimmat.df10$CNT, levels=remasco.sort$Country, ordered=T)

my.settings.three <- list(
  superpose.polygon=list(col=myColours[c(4)], border="yellow", lwd=2)
  ,strip.background=list(col=myColours[6])
  ,strip.border=list(col="black")
  ,background=list(col="white")
  ,axis.line=list(col="black", lwd=2)
  ,superpose.symbol=list(col=myColours[c(4)], pch=16)
  ,plot.symbol=list(pch=16, col=myColours[c(4)], fill=myColours[c(4)])
  ,add.text=list(col="white", font=2)
)

png("Math.png", width = 2048, height = 1152, res=200)
#Lm.fit with weights
coun.vec <- as.vector(unique(coutimmat.df10$CNT))
par(mfrow=c(4,3), oma=c(1,1,1,1), mar=c(2,2,2,2))
for(i in 1:length(coun.vec)) {
  coun.tmp <- coun.vec[i]
df.tmp <- coutimmat.df10[coutimmat.df10$CNT==coun.tmp,]
lm.tmp <- lm( PV1MATH ~ MMINS, , data=df.tmp, weights=W_FSTUWT )
plot(
       df.tmp$MMINS, df.tmp$PV1MATH, pch=16, col="green"
      ,main=coun.tmp
      #,xlab="Minutes of study"
      ,xlab=""
      ,ylab=""
      #,ylab="PV1MATH"
      ,col.lab="blue", cex.lab=1.2, font.lab=2, las=1, cex.axis=0.8, font.axis=2, col.axis="blue"
    )
abline(lm.tmp$coefficients, col="red", lty=1, lwd=2)
}
plot(0.5,0.5, pch=".", axes=FALSE)
text(0.5,0.5, "More effort, better results?", col="red", font=2, cex=2)
plot(0.5,0.5, pch=".", axes=FALSE)
text(0.5,0.5, "PV1MATH", col="red", font=2, cex=4)
dev.off()


#----------
# Reading
coutimrea.df <- student2012[, c("CNT", "PV1READ", "LMINS", "W_FSTUWT")]
coutimrea.df <- coutimrea.df[-grep(coutimrea.df$CNT, pattern="(", fixed=TRUE),]

xyplot(
  PV1READ ~ LMINS | CNT 
  ,data=coutimrea.df
  ,xlab = "Minutes of study"
  ,ylab="PV1READ"
  ,main="READING"
  ,layout=c(4,4)
  ,scales="free"  
  ,as.table=TRUE
)  

#Top-10
coun10.top <- as.vector(unique(remaSco.df10$Country))
coutimrea.df10 <- coutimrea.df[coutimrea.df$CNT %in% coun10.top, ]
coutimrea.df10$CNT <- factor(coutimrea.df10$CNT, levels=remasco.sort$Country, ordered=T)

png("Reading.png", width = 2048, height = 1152, res=200)
#Lm.fit with weights
coun.vec <- as.vector(unique(coutimrea.df10$CNT))
par(mfrow=c(4,3), oma=c(1,1,1,1), mar=c(2,2,2,2))
for(i in 1:length(coun.vec)) {
  coun.tmp <- coun.vec[i]
  df.tmp <- coutimrea.df10[coutimrea.df10$CNT==coun.tmp,]
  lm.tmp <- lm( PV1READ ~ LMINS, , data=df.tmp, weights=W_FSTUWT )
  plot(
    df.tmp$LMINS, df.tmp$PV1READ, pch=16, col="green"
    ,main=coun.tmp
    #,xlab="Minutes of study"
    ,xlab=""
    ,ylab=""
    #,ylab="PV1MATH"
    ,col.lab="blue", cex.lab=1.2, font.lab=2, las=1, cex.axis=0.8, font.axis=2, col.axis="blue"
  )
  abline(lm.tmp$coefficients, col="red", lty=1, lwd=2)
}
plot(0.5,0.5, pch=".", axes=FALSE)
text(0.5,0.5, "More effort, better results?", col="red", font=2, cex=2)
plot(0.5,0.5, pch=".", axes=FALSE)
text(0.5,0.5, "PV1READ", col="red", font=2, cex=4)
dev.off()


# Science
coutimsci.df <- student2012[, c("CNT", "PV1SCIE", "SMINS", "W_FSTUWT")]
coutimsci.df <- coutimsci.df[-grep(coutimsci.df$CNT, pattern="(", fixed=TRUE),]

xyplot(
  PV1SCIE ~ SMINS | CNT 
  ,data=coutimsci.df
  ,xlab = "Minutes of study"
  ,ylab="PV1SCIE"
  ,main="SCIENCE"
  ,layout=c(4,4)
  ,scales="free"  
  ,as.table=TRUE
)  

#Top-10
coun10.top <- as.vector(unique(remaSco.df10$Country))
coutimsci.df10 <- coutimsci.df[coutimsci.df$CNT %in% coun10.top, ]
coutimsci.df10$CNT <- factor(coutimsci.df10$CNT, levels=remasco.sort$Country, ordered=T)


png("Science.png", width = 2048, height = 1152, res=200)
#Lm.fit with weights
coun.vec <- as.vector(unique(coutimsci.df10$CNT))
par(mfrow=c(4,3), oma=c(1,1,1,1), mar=c(2,2,2,2))
for(i in 1:length(coun.vec)) {
  coun.tmp <- coun.vec[i]
  df.tmp <- coutimsci.df10[coutimsci.df10$CNT==coun.tmp,]
  lm.tmp <- lm( PV1SCIE ~ SMINS, , data=df.tmp, weights=W_FSTUWT )
  plot(
    df.tmp$SMINS, df.tmp$PV1SCIE, pch=16, col="green"
    ,main=coun.tmp
    #,xlab="Minutes of study"
    ,xlab=""
    ,ylab=""
    #,ylab="PV1MATH"
    ,col.lab="blue", cex.lab=1.2, font.lab=2, las=1, cex.axis=0.8, font.axis=2, col.axis="blue"
  )
  abline(lm.tmp$coefficients, col="red", lty=1, lwd=2)
}
plot(0.5,0.5, pch=".", axes=FALSE)
text(0.5,0.5, "More effort, better results?", col="red", font=2, cex=2)
plot(0.5,0.5, pch=".", axes=FALSE)
text(0.5,0.5, "PV1SCIE", col="red", font=2, cex=4)
dev.off()


#--------------------------------------------------------------
#"ST43Q01" "Perceived Control - Can Succeed with Enough Effort"
coun10.top <- as.vector(unique(remaSco.df10$Country))
per.ctrl <- student2012[ ,c('CNT','ST43Q01')]
per.ctrl.10 <- per.ctrl[per.ctrl$CNT %in% coun10.top, ]
per.ctrl.10$CNT <- as.vector(per.ctrl.10$CNT)
per.ctrl.10.per <- as.data.frame(table(per.ctrl.10$CNT, per.ctrl.10$ST43Q01))
names(per.ctrl.10.per) <- c('Country','PercCtrl','Frequency')

per.ctrl.10.per$Country <- factor(per.ctrl.10.per$Country, levels=remasco.sort$Country, ordered=T)

precon.gr <- likert(
   Country ~ PercCtrl
  ,value="Frequency"
  ,data=per.ctrl.10.per
  ,as.percent=TRUE
  ,main="Perceived Control - Can Succeed with Enough Effort (ST43Q01)\n(Top-10 Countries)"
  ,data.order=TRUE
        ,scales=list(cex=0.9, font=2, col="black", relation="free")
)




#223" "ST83Q01" "Teacher Support - Lets Us Know We Have to Work Hard"
coun10.top <- as.vector(unique(remaSco.df10$Country))
tea.sup <- student2012[ ,c('CNT','ST83Q01')]
tea.sup.10 <- tea.sup[tea.sup$CNT %in% coun10.top, ]
tea.sup.10$CNT <- as.vector(tea.sup.10$CNT)
tea.sup.10.per <- as.data.frame(table(tea.sup.10$CNT, tea.sup.10$ST83Q01))
names(tea.sup.10.per) <- c('Country','TeaSup','Frequency')

tea.sup.10.per$Country <- factor(tea.sup.10.per$Country, levels=remasco.sort$Country, ordered=T)

teach.gr <- likert(
  Country ~ TeaSup
  ,value="Frequency"
  ,data=tea.sup.10.per
  ,as.percent=TRUE
  ,main="Teacher Support - Lets us know we have to work hard (ST83Q01)\n(Top-10 Countries)"
  ,data.order=TRUE
        ,scales=list(cex=0.9, font=2, col="black", relation="free")
)



#"265" "ST93Q06" "Perseverance - Continue to perfection"
coun10.top <- as.vector(unique(remaSco.df10$Country))
per.con <- student2012[ ,c('CNT','ST93Q06')]
per.con.10 <- per.con[per.con$CNT %in% coun10.top, ]
per.con.10$CNT <- as.vector(per.con.10$CNT)
per.con.10.per <- as.data.frame(table(per.con.10$CNT, per.con.10$ST93Q06))
names(per.con.10.per) <- c('Country','PerCon','Frequency')

per.con.10.per$Country <- factor(per.con.10.per$Country, levels=remasco.sort$Country, ordered=T)

perse.gr <- likert(
  Country ~ PerCon 
  ,value="Frequency"
  ,data=per.con.10.per
  ,as.percent=TRUE
  ,main="Teacher Perseverance - Continue to perfection (ST93Q06)\n(Top-10 Countries)"
  ,data.order=TRUE
  ,levelsName=" "
        ,scales=list(cex=0.9, font=2, col="black", relation="free")
)



#----------
#---- Save charts for external composition
png("Rplot%03d.png", width = 2048, height = 1152, res=200)
print(One.gr)
print(Oneone.gr)
print(male.gr)
print(female.gr)
print(precon.gr)
print(teach.gr)
print(perse.gr)
dev.off()


#--------------------------
#---- END OF PROGRAM
#--------------------------


#Each submission should be sent as a separate email to: user2014contest@gmail.com.
#The email with submission should have following information:
#Name and contact information of the author. For group submissions one person should be selected as ‘the principal investigator'. 
#You can submit work ONLY IF you are the main author and you have full rights to the submitted work.
#Attachment: a single png file with the visualisation. The resolution of the file should not be larger than 2048 x 1152 px. 
#The visualisation should be related to one of the contest tracks and should contain graphs or analyses created with R. 
#The png file can be produced directly by R or can be created using other tools (like Inkscape).
#Attachment: One or more files containing R codes to enable to replicate all graphs and analyses used in visualization.
#All submissions need to be licensed under Creative Common BY&SA license.
#Submitted works must be original. Previously published works will not be accepted.
#Only submissions that are sent before midnight Sunday 29 June 2014 Pacific Daylight Time (UTC -7) will be considered.


#--------------------------------------
# END OF PROGRAM
#--------------------------------------