rm( list = ls() )

library( plotrix )
# REQUIRED LIBRARY
# Lemon, J. (2006) Plotrix: a package in the red light district of R. R-News, 6(4): 8-12.
# License: GPL-2 | GPL-3 [expanded from: GPL (>= 2)]
# see http://cran.r-project.org/web/packages/plotrix/index.html


# CHANGE PATH BELOW TO REPRODUCE RESULS - THE FOLDER MUST CONTAIN 
# STUDENT2012.RDA

path <- "C:/Users/Kimon/Documents/R_Work/PISA contest/"

pv_mean <- function( df, categ ) {
  # returns mean of plausible values for a category ( "MATH", "READ", "SCIE" )
  # as the average of the weighted means of the corresponding 5 variables

  # inputs:
  # df : the dataframe derived from student2012
  #   containing data for a specific combination of country/ region and 
  #   immigrant status (1=natives, 3=first generation migrants)
  # categ: one of "MATH", "READ", "SCIE"
 
  stu.weight.ind <-  match("W_FSTUWT", names( df ) )

  vars <- grep( categ, names( df ) )

  w.mean <- 0	
  for( i in 1 : 5 ) {
  	w.mean <- w.mean + weighted.mean( df[ , vars[ i ] ], df[ , stu.weight.ind ], na.rm = TRUE )
  }
  w.mean <- w.mean / 5
  return( w.mean )
}


# STEP 1
# -----------
# load student2012, select required variables and create two auxiliary numeric variables 
#   corresponding to factors CNT and IMMIG
# also split resulting dataframe into the combinations (country/ region and natives/ 1G migrants)


load( paste( path, "student2012.rda", sep = "" ) )

keeps <- c( "CNT", "OECD", "IMMIG", 
"PV1MATH", "PV2MATH", "PV3MATH", "PV4MATH", "PV5MATH",
"PV1READ", "PV2READ", "PV3READ", "PV4READ", "PV5READ",
"PV1SCIE", "PV2SCIE", "PV3SCIE", "PV4SCIE", "PV5SCIE", "W_FSTUWT" )

df <- student2012[ ,names( student2012 ) %in% keeps ]

df <- within( df, {
  CNT_code <- as.integer( CNT )
  IMMIG_code <- as.integer( IMMIG ) } )

nrows <- length( levels( df$CNT ) ) # 68 countries and regions, 485490 observations 

df.split <- split( df, list( df$CNT_code, df$IMMIG_code ) )
# a list of 68 x 3 = 204 dataframes
# running first on IMMIG then on CNT
# for IMMIG=1 (natives): 1...68
# for IMMIG=3 (1G migrants): 137...204

rm( student2012, keeps )


# STEP 2
# -----------
# start building dataframe with one row per country/ region: country name, numeric index of country,
# 3-code for country and a variable OECD.yes (0=non OECD, 1=OECD)

countries <- levels( df$CNT )

df.countries <- data.frame( CNT = countries, CNT_CODE = 1:nrows, 
  CNT_CODE2 = c( 
  "ALB","ARE","ARG","AUS","AUT","BEL","BGR","BRA","CAN","CHE","CHL","COL",
  "CRI","CZE","DEU","DNK","ESP","EST","FIN","FRA","GBR","GRC","HKG","HRV",
  "HUN","IDN","IRL","ISL","ISR","ITA","JOR","JPN","KAZ","KOR","LIE","LTU",
  "LUX","LVA","MAC","MEX","MNE","MYS","NLD","NOR","NZL","PER","POL","PRT",
  "QAT","QCN","QRS","QUA","QUB","QUC","ROU","RUS","SGP","SRB","SVK","SVN",
  "SWE","TAP","THA","TUN","TUR","URY","USA","VNM" ), 
  stringsAsFactors = F )

ttt <- table(df$CNT, df$OECD )[ ,2 ]
ttt <- ifelse( ttt > 1, 1, 0 )

df.countries <- cbind( df.countries, OECD.yes = ttt )


# STEP 3
# -----------
# calculate means of plausible values for all countries/ regions
# in the categories "MATH", "READ", "SCIE",
# for natives and 1G migrants 


MATH_NAT <- vector( mode = "numeric", length = nrows )
MATH_1G <- vector( mode = "numeric", length = nrows )
READ_NAT <- vector( mode = "numeric", length = nrows )
READ_1G <- vector( mode = "numeric", length = nrows )
SCIE_NAT <- vector( mode = "numeric", length = nrows )
SCIE_1G <- vector( mode = "numeric", length = nrows )

for( i in 1 : nrows ) {
  MATH_NAT[ i ] <- pv_mean( df.split[[ i ]], "MATH" )
  MATH_1G[ i ]  <- pv_mean( df.split[[ 136 + i ]], "MATH" )
  READ_NAT[ i ] <- pv_mean( df.split[[ i ]], "READ" )
  READ_1G[ i ]  <- pv_mean( df.split[[ 136 + i ]], "READ" )
  SCIE_NAT[ i ] <- pv_mean( df.split[[ i ]], "SCIE" )
  SCIE_1G[ i ]  <- pv_mean( df.split[[ 136 + i ]], "SCIE" )
}
df.countries <- cbind( df.countries, MATH_NAT, MATH_1G, READ_NAT, READ_1G, 
  SCIE_NAT, SCIE_1G )


# STEP 4
# -----------
# add one record for OECD average ( NOT total )
#   used when the focus is on comparing performance across education systems
# assume performance is the average of performances in MATH, READ and SCIE
#   and compute corresponding variables
# also exclude some regions 
#   and shorten some names 


oecd.ave <- with( df.countries, {
  list( CNT = "OECD Aver.", CNT_CODE = nrows + 1, CNT_CODE2 = "OECD", OECD.yes = 9,
  MATH_NAT = mean( MATH_NAT[ OECD.yes == 1 ] ),
  MATH_1G =  mean( MATH_1G[  OECD.yes == 1 ] ),
  READ_NAT = mean( READ_NAT[ OECD.yes == 1 ] ),
  READ_1G =  mean( READ_1G[  OECD.yes == 1 ] ),
  SCIE_NAT = mean( SCIE_NAT[ OECD.yes == 1 ] ),
  SCIE_1G =  mean( SCIE_1G[  OECD.yes == 1 ] ) )
} )

df.countries <- rbind( df.countries, oecd.ave )
df.countries <- within( df.countries, {
  PERF_NAT <- ( MATH_NAT + READ_NAT + SCIE_NAT )/3
  PERF_1G <- ( MATH_1G + READ_1G + SCIE_1G ) /3
  DIFF <- PERF_NAT - PERF_1G #absolute difference, to do some analysis for own interest
})


# excluding Perm(Russian Federation), Florida (USA), Connecticut (USA), Massachusetts (USA)
df.countries <- subset( df.countries, !( CNT_CODE %in% c( 51, 52, 53, 54 ) ) )

df.countries <- within( df.countries, {
  CNT[ CNT_CODE == 67 ] <- "USA" 
  CNT[ CNT_CODE == 2 ] <- "Arab Emirates" 
  OECD.yes[ CNT_CODE == 69 ] <- 1
} )

row.names( df.countries ) = seq( 1: nrow( df.countries ) )

View( df.countries )


# STEP 5
# -----------

# save these results as the final data for the visualisation
# order by decreasing performance in natives
# split data in non-OECD, OECD for the double plot
# and bring them in the format required by the plotting function 

save( df.countries , file = paste( path, "countries_v4.Rdata", sep = "" ) )
write.table(df.countries, file = paste( path, "countries_v4.csv", sep = "" ), append = FALSE, quote = TRUE, sep = ";",
            eol = "\n", na = "", dec = ",", row.names = FALSE,
            col.names = TRUE )

rm( df, df.split )

load( file = paste( path, "countries_v4.Rdata", sep = "" ) )

df.countries <- df.countries[ 
  with( df.countries, order( -PERF_NAT ) ), ]
row.names( df.countries ) = seq( 1: nrow( df.countries ) )

split.OECD <-split( df.countries, df.countries$OECD.yes )

# format required in first argument in call to radial.plot()
# see http://cran.r-project.org/web/packages/plotrix/plotrix.pdf
lengths1 = t( cbind( split.OECD[[1]]$PERF_NAT, split.OECD[[1]]$PERF_1G ) )
lengths2 = t( cbind( split.OECD[[2]]$PERF_NAT, split.OECD[[2]]$PERF_1G ) )

# STEP 6
# -----------
# Plotting

def.par <- par(no.readonly = TRUE)

dev.off()
dev.new( width=20, height=11 )
par( mfrow = c( 1, 2 ), xpd = TRUE ) 

par( ps = 6, lwd = 1.0, bg = "white", cex.lab = 1.5, 
cex.axis = 1.4, cex.main = 2, col.main = "darkolivegreen", family = "sans" )
par( mar =  c( 0, 0, 5, 0 ) ) # bottom, left, top, right
par( oma =  c( 0, 0, 1, 0 ) ) # bottom, left, top, right


# see http://cran.r-project.org/web/packages/plotrix/plotrix.pdf
do.radial.plot <- function ( lengths, labels, main ) {
  rp <- radial.plot( lengths = lengths,
  labels = labels,
  start = 1,
  clockwise = T,
  rp.type = "p",
  main = main, 
  label.prop = 1.1,
  line.col = c( "blue", "darkred" ),
  lwd = c( 2.5, 2.5 ), 
  rad.col = "grey",
  grid.col = "grey",
  radial.lim = c( 300, 600 ) )
  return( rp )
}
do.radial.plot( lengths1, split.OECD[[1]]$CNT, "non-OECD")
do.radial.plot( lengths2, split.OECD[[2]]$CNT, "OECD")

mtext( "Average performance in natives and first generation immigrants",
 side = 3, line = -1, outer = TRUE, cex = 2.5, col = "blue", font = 2, family = "sans" )
mtext( "in non-OECD and OECD countries",
 side = 3, line = -2, outer = TRUE, cex = 2.0, col = "blue", font = 2, family = "sans" )

legend( x =  -470, y = -280, legend = c( "Natives", "1G immigrants" ), col = c( "blue", "darkred" ), xpd = NA,
bty = "o", box.col = "darkolivegreen", lty = 1, lwd = 2, cex = 1.5, y.intersp = 0.5 )


par(def.par)



