setwd("~/PISA/")
load("student2012.rda")


library(dplyr)
library(Hmisc)
library(ggplot2)
library(reshape2)

#Subset the data for valid variables only
tr_stu2012 <- student2012%.%
  select(CNT,OECD,PV1MATH,PV1READ,PV1SCIE,W_FSTUWT)

rm(student2012)

summary(tr_stu2012)

#Country and continents
cntry <- with(tr_stu2012, unique(CNT))
#Naming the continents for better view
continents <- c(
  'Europe',
  'Asia',
  'S. America',
  'Oceania',
  'Europe',
  'Europe',
  'Europe',
  'S. America',
  'N. America',
  'Europe',
  'S. America',
  'S. America',
  'N. America',
  'Europe',
  'Europe',
  'Europe',
  'Europe',
  'Europe',
  'Europe',
  'Europe',
  'Europe',
  'Europe',
  'Asia',
  'Europe',
  'Europe',
  'Asia',
  'Europe',
  'Europe',
  'Asia',
  'Europe',
  'Asia',
  'Asia',
  'Asia',
  'Asia',
  'Europe',
  'Europe',
  'Europe',
  'Europe',
  'Asia',
  'S. America',
  'Europe',
  'Asia',
  'Europe',
  'Europe',
  'Oceania',
  'S. America',
  'Europe',
  'Europe',
  'Asia',
  'Asia',
  'Asia',
  'N. America',
  'N. America',
  'N. America',
  'Europe',
  'Asia',
  'Asia',
  'Europe',
  'Europe',
  'Europe',
  'Europe',
  'Asia',
  'Asia',
  'Africa',
  'Asia',
  'S. America',
  'N. America',
  'Asia'
  )

cntry.cont <- cbind(as.data.frame(cntry),as.data.frame(continents))
names(cntry.cont) <- c("CNT", "Continent")


#Merge continents into original data
tr_stu2012 <- left_join(tr_stu2012, cntry.cont, by = "CNT")


#Summarize data (Calculate OECD Percentiles)
oecd <- tr_stu2012%.%
  filter(OECD == "OECD")%.%
  summarise(oecd_25 = wtd.quantile(PV1MATH, weights=
                                     W_FSTUWT,
                                   probs = .25),
            oecd_md = wtd.quantile(PV1MATH, weights=
                                     W_FSTUWT,
                                   probs = .5),
            oecd_75 = wtd.quantile(PV1MATH, weights=
                                     W_FSTUWT,
                                   probs = .75))

#Summarize data (Calculate country wise Percentiles)
all_cntry <-  tr_stu2012%.%
  group_by(CNT, Continent)%.%
  summarise(cntry_25 = wtd.quantile(PV1MATH, weights=
                                     W_FSTUWT,
                                   probs = .25),
            cntry_md = wtd.quantile(PV1MATH, weights=
                                     W_FSTUWT,
                                   probs = .5),
            cntry_75 = wtd.quantile(PV1MATH, weights=
                                     W_FSTUWT,
                                   probs = .75))%.%
  mutate(cntry_md25 = cntry_md - cntry_25,
         cntry_md75 = cntry_75 - cntry_md)%.%
  arrange(cntry_md)

#Merge oecd values in all_cntry
all_cntry <- cbind(all_cntry, oecd)

m_all_cntry <- melt(all_cntry)

graph_plot <- function(x="S. America")
{
library(plyr)
gg <- ggplot(data = m_all_cntry)
gg_layer <- gg + geom_bar(aes(x=CNT, y=value, fill=variable), position = "stack", subset =
                .(variable %in% c("cntry_25","cntry_md25","cntry_md75") & Continent %in% x),stat="identity")+
  geom_hline(aes(yintercept = value), linetype = "dashed", size = 1.05, colour = "brown" ,show_guide = F, subset = .(variable %in% c("oecd_md") & Continent %in% x))+ theme(axis.text.x=element_text(angle=90, hjust=1),panel.grid.major=element_blank(), panel.grid.minor=element_blank(),plot.title = element_text(lineheight=1, face="bold"))+
  scale_fill_discrete(name="Quartiles",
                      labels=c("25th Percentile", "50th Percentile", "75th Percentile"))+
  geom_text(aes(x=5,y=500,label = "OECD Median PV1MATH Score"))+xlab("Countries")+ylab("PV1MATH Score")+ggtitle(paste("Percentage of population lying below OECD Median PV1MATH Score for", x, sep = " "))
detach("package:plyr")
print(gg_layer)
}

graph_plot(x = "S. America")
#graph_plot(x="Europe")
#graph_plot(x="Asia")
#graph_plot(x="N. America")
