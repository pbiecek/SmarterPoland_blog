/*jQuery lightBox v.0.4*/
(function($){$.fn.lightBox=function(settings){settings=jQuery.extend({overlayBgColor:'#000',overlayOpacity:0.8,imLoad:base_href + 'images/lightbox-ico-loading.gif',imBPr:base_href+'images/lightbox-btn-prev.gif',imBNx:base_href + 'images/lightbox-btn-next.gif',imBCl:base_href + 'images/lightbox-btn-close.gif',imBl:base_href + 'images/lightbox-blank.gif',conBorS:10,conResS:40,txtImage:'',txtOf:'/',keyToClose:'c',keyToPrev:'p',keyToNext:'n',imageArray:[],activeImage:0},settings);var jQueryMatchedObj=this;function _initialize(){_start(this,jQueryMatchedObj);return false;}function _start(objClicked,jQueryMatchedObj){$('embed, object, select').css({'visibility':'hidden'});_sinter();settings.imageArray.length=0;settings.activeImage=0;if(jQueryMatchedObj.length==1){settings.imageArray.push(new Array(objClicked.getAttribute('href'),objClicked.getAttribute('title')));
}else{for(var i=0;i<jQueryMatchedObj.length;i++)settings.imageArray.push(new Array(jQueryMatchedObj[i].getAttribute('href'),jQueryMatchedObj[i].getAttribute('title')));}while(settings.imageArray[settings.activeImage][0]!=objClicked.getAttribute('href'))settings.activeImage++;_sitv();}function _sinter(){$('body').append('<div id="jquery-overlay"></div><div id="jquery-lightbox"><div id="lightbox-container-image-box"><div id="lightbox-container-image"><img id="lightbox-image"><div style="" id="lightbox-nav"><a href="#" id="lightbox-nav-btnPrev"></a><a href="#" id="lightbox-nav-btnNext"></a></div><div id="lightbox-loading"><a href="#" id="lightbox-loading-link"><img src="' + settings.imLoad + '"></a></div></div></div><div id="lightbox-container-image-data-box"><div id="lightbox-container-image-data"><div id="lightbox-image-details"><span id="lightbox-image-details-caption"></span><span id="lightbox-image-details-currentNumber"></span></div><div id="lightbox-secNav"><a href="#" id="lightbox-secNav-btnClose"><img src="'+settings.imBCl+'"></a></div></div></div></div>');var arrPageSizes = ___getPS();$('#jquery-overlay').css({backgroundColor:settings.overlayBgColor,opacity:settings.overlayOpacity,width:arrPageSizes[0],height:arrPageSizes[1]}).fadeIn();var arrPageScroll=___getPScr();$('#jquery-lightbox').css({top:arrPageScroll[1]+(arrPageSizes[3]/10),left:arrPageScroll[0]}).show();$('#jquery-overlay,#jquery-lightbox').click(function(){_fin();});$('#lightbox-loading-link,#lightbox-secNav-btnClose').click(function(){_fin();return false;});$(window).resize(function(){var arrPageSizes = ___getPS();$('#jquery-overlay').css({width:arrPageSizes[0],height:arrPageSizes[1]});var arrPageScroll=___getPScr();$('#jquery-lightbox').css({top:arrPageScroll[1]+(arrPageSizes[3]/10),left:arrPageScroll[0]});});}function _sitv(){$('#lightbox-loading').show();$('#lightbox-image,#lightbox-nav,#lightbox-nav-btnPrev,#lightbox-nav-btnNext,#lightbox-container-image-data-box,#lightbox-image-details-currentNumber').hide();var objImagePreloader=new Image();objImagePreloader.onload=function(){$('#lightbox-image').attr('src',settings.imageArray[settings.activeImage][0]);_resconib(objImagePreloader.width,objImagePreloader.height);objImagePreloader.onload=function(){};};objImagePreloader.src=settings.imageArray[settings.activeImage][0];};function _resconib(intImageWidth,intImageHeight){var intCurrentWidth=$('#lightbox-container-image-box').width();var intCurrentHeight=$('#lightbox-container-image-box').height();var intWidth=(intImageWidth+(settings.conBorS*2));var intHeight=(intImageHeight+(settings.conBorS*2));var intDiffW=intCurrentWidth-intWidth;var intDiffH=intCurrentHeight-intHeight;$('#lightbox-container-image-box').animate({width:intWidth, height:intHeight},settings.conResS,function(){_show_image();});if((intDiffW== 0)&&(intDiffH==0)){if($.browser.msie)___pa(250);else ___pa(100);}$('#lightbox-nav-btnPrev,#lightbox-nav-btnNext').css({height:intImageHeight+(settings.conBorS * 2)});$('#lightbox-container-image-data-box').css({width:intImageWidth});};function _show_image(){$('#lightbox-loading').hide();$('#lightbox-image').fadeIn(function(){$('#lightbox-container-image-data-box').slideDown('fast');$('#lightbox-image-details-caption').hide();if(settings.imageArray[settings.activeImage][1])$('#lightbox-image-details-caption').html(settings.imageArray[settings.activeImage][1]).show();if(settings.imageArray.length>1)$('#lightbox-image-details-currentNumber').html(settings.txtImage+' '+(settings.activeImage+1)+' '+settings.txtOf+' '+settings.imageArray.length).show();_snav();});if((settings.imageArray.length-1)>settings.activeImage){objNext=new Image();objNext.src=settings.imageArray[settings.activeImage+1][0];}if(settings.activeImage>0){objPrev = new Image();objPrev.src = settings.imageArray[settings.activeImage-1][0];}};function _snav(){$('#lightbox-nav').show();$('#lightbox-nav-btnPrev,#lightbox-nav-btnNext').css({'background':'transparent url(' + settings.imBl + ') no-repeat'});if(settings.activeImage!= 0){$('#lightbox-nav-btnPrev').unbind().hover(function(){$(this).css({'background':'url('+settings.imBPr+') left 15% no-repeat'});},function(){
$(this).css({'background':'transparent url('+settings.imBl+') no-repeat'});}).show().bind('click',function(){settings.activeImage=settings.activeImage-1;_sitv();
return false;});}if(settings.activeImage!=(settings.imageArray.length-1)){$('#lightbox-nav-btnNext').unbind().hover(function(){$(this).css({'background':'url('+settings.imBNx+') right 15% no-repeat'});},function(){$(this).css({'background':'transparent url('+settings.imBl+') no-repeat'});}).show().bind('click',function(){settings.activeImage=settings.activeImage+1;_sitv();
return false;});}$(document).keydown(function(objEvent){if(objEvent==null){keycode=event.keyCode;escapeKey=27;}else{keycode=objEvent.keyCode;escapeKey=objEvent.DOM_VK_ESCAPE;}key=String.fromCharCode(keycode).toLowerCase();if((key==settings.keyToClose)||(key=='x')||(keycode==escapeKey)){_fin();}if((key == settings.keyToPrev)||(keycode == 37)){if( settings.activeImage!=0){settings.activeImage=settings.activeImage-1;_sitv();$(document).unbind();}}if((key==settings.keyToNext)||(keycode==39)){if(settings.activeImage!=( settings.imageArray.length-1)){settings.activeImage=settings.activeImage+1;
_sitv();$(document).unbind();}}});}function _fin(){$('#jquery-lightbox').remove();$('#jquery-overlay').fadeOut(30,function(){$('#jquery-overlay').remove();});$('embed, object, select').css({'visibility':'visible'});}function ___getPS(){var xScroll, yScroll;if (window.innerHeight && window.scrollMaxY){xScroll=window.innerWidth + window.scrollMaxX;yScroll=window.innerHeight + window.scrollMaxY;}else if(document.body.scrollHeight>document.body.offsetHeight){xScroll=document.body.scrollWidth;yScroll=document.body.scrollHeight;}else{xScroll=document.body.offsetWidth;
yScroll=document.body.offsetHeight;}var windowWidth, windowHeight;if(self.innerHeight){if(document.documentElement.clientWidth)windowWidth=document.documentElement.clientWidth; else windowWidth=self.innerWidth;windowHeight=self.innerHeight;}else if(document.documentElement && document.documentElement.clientHeight){windowWidth=document.documentElement.clientWidth;windowHeight=document.documentElement.clientHeight;}else if (document.body){windowWidth=document.body.clientWidth;windowHeight=document.body.clientHeight;}if(yScroll<windowHeight)pageHeight=windowHeight;else pageHeight=yScroll;if(xScroll<windowWidth) pageWidth=xScroll; else pageWidth=windowWidth;arrayPageSize=new Array(pageWidth,pageHeight,windowWidth,windowHeight) 
return arrayPageSize;};function ___getPScr(){var xScroll, yScroll;if (self.pageYOffset){yScroll=self.pageYOffset;xScroll=self.pageXOffset;} else if(document.documentElement && document.documentElement.scrollTop){yScroll=document.documentElement.scrollTop;xScroll=document.documentElement.scrollLeft;} else if(document.body){yScroll=document.body.scrollTop;
xScroll=document.body.scrollLeft;}arrayPageScroll=new Array(xScroll,yScroll);return arrayPageScroll;};function ___pa(ms){var date=new Date();curDate=null;do{var curDate=new Date();} while(curDate-date<ms);};return this.unbind('click').click(_initialize);};})(jQuery);

/* Zarz�dzanie wykonywaniem skryptow po doczytaniu strony */
var EditoStart = new Object();
EditoStart.functions = new Array();

EditoStart.Add = function(fnc)
{
	EditoStart.functions[EditoStart.functions.length] = fnc;
}

EditoStart.init = function()
{
	for(var i = 0; i < EditoStart.functions.length; i++)
	{
		EditoStart.functions[i]();
	}
}

$(document).ready(function()
{
	EditoStart.init();
});

$(document).ready(function()
{
	// Przegladarka zdjec
	$('a[rel*=lightbox]').lightBox();
	$('a[class*=lightbox]').lightBox();
	
	//zabezpieczenie przed 2-krotnym wysylaniem formularzy
	$('form:not(.jquery_form)').bind('submit', function(){
		$('input[type=submit]', this).attr('disabled', 'disabled');
	}) 	
	// tabelka w IE 7
	if ($.browser.msie && $.browser.version <= 7.0)
		$(".tabelka-bordo tr:last").addClass('last');
	
	// kontrolka wyboru wersji językowej
	$('.jezyki li:first').hover(function() {
		$(this).siblings().show();
	});
	$('.jezyki').bind('mouseleave', function() {
		$(this).find('li:not(:first)').hide();
	});
	

	// zmiana rozmiaru czcionki
		// odczytanie ustawionej wartości z ciasteczka
	if(getCookie("font-size") == "medium"){
		$('.font-resize').each(function(){
			$(this).removeClass('font-large');
			$(this).addClass('font-medium');
		});	
	}
	if(getCookie("font-size") == "large"){
		$('.font-resize').each(function(){
			$(this).removeClass('font-medium');
			$(this).addClass('font-large');
		});	
	}
		// zmiana rozmiaru po kliknieciu
	$('.font-size .medium').click(function(){
		$('.font-resize').each(function(){
			$(this).removeClass('font-large');
			$(this).addClass('font-medium');
		});
		setCookie("font-size","medium",0,'/');
	});
	$('.font-size .large').click(function(){
		$('.font-resize').each(function(){
			$(this).removeClass('font-medium');
			$(this).addClass('font-large');
		});
		setCookie("font-size","large",0,'/');
	});
	$('.font-size .small').click(function(){
		$('.font-resize').each(function(){
			$(this).removeClass('font-medium');
			$(this).removeClass('font-large');
		});
		setCookie("font-size",null,0,'/');
	});

	// tabulacja po linkach w operze - nadanie atrybutow tabindex
 	if($.browser.opera || $.browser.mozilla)
 	{
		tab_links = $('a, input, select, textarea');
		for(var i = 0; i < tab_links.length; i++)
		{
			$(tab_links[i]).attr('tabindex', i+1);
		}
	}
	
});


function insertActiveX(html)
{
	document.write(html);
}

/* Pozostale skrypty */

function findObj(obj) {
	return document.getElementById(obj);
}

function preloadimages(images) {
	if (!images) {
		var images = new Array();
	}
	var img = new Array();
	for (i=0; i<images.length; i++) {
		img[i] = new Image();
		img[i].src = images[i];
	}
}

function swapImage(id, img) {
	o = findObj(id);
	if(o)
		o.src = img;
}

function SendTo(before, after, user, host, label) {
	label = label.replace(' // ', '@');
	document.write('<a' + before + 'href="mailto:' + user + '@' + host + '"' + after+'>' + label + '</a>');
}

// popup
function popUpWindow(src, w, h) {
	noweOkienko = null;
	if (window.screen) {
		aw = screen.availWidth;
		ah = screen.availHeight;
	} else {
		aw = 640;
		ah = 450;
	}
	if (noweOkienko==null || noweOkienko.closed) {
		ustawienia=
		"left=" + (aw-w)/2 + ","
		+"top=" + (ah-h)/2 + ","
		+"screenX=" + (aw-w)/2 + ","
		+"screenY=" + (ah-h)/2 + ","
		+"width=" + w + ","
		+"height=" + h + ","
		+"innerWidth=" + w + ","
		+"innerHeight=" + h + ","
		+"toolbar=no,"
		+"location=no,"
		+"directories=no,"
		+"status=yes,"
		+"menubar=no,"
		+"scrollbars=yes,"
		+"resizable=no"
		var url = '/' + src; 
		noweOkienko = window.open(url, 'plik', ustawienia);
	}
	try {
		noweOkienko.focus();
	}
	catch (e) {
	}
}

// rozwijanie listy wynikow w wyszukiwarce
function showResult(id) {
	o = document.getElementById(id);
	if (o.style.display == '' || o.style.display == 'none') {
		o.style.display = 'block';
	} else {
		o.style.display = 'none';
	}
}

function limiter(obj, limit) {
	if (obj.value.length > limit) {
		obj.value = obj.value.substring(0,limit);
	}
}

// obliczanie pozostalych znakow w textarea
function limit(obj, limit, msg) {
	if (obj.value.length > limit) {
		obj.value = obj.value.substring(0,limit);
		alert(msg);
	}
}

function getCookie(name)
{
	var dc = document.cookie;
	var cname = name + "=";
	var clen = dc.length;
	var cbegin = 0;
	
	while (cbegin < clen)
	{ 
		var vbegin = cbegin + cname.length;
	
		if (dc.substring(cbegin, vbegin) == cname)
		{ 
			var vend = dc.indexOf (";", vbegin);
			if (vend == -1) vend = clen;
	
			return unescape(dc.substring(vbegin, vend));
		}
	
		cbegin = dc.indexOf(" ", cbegin) + 1;
	
		if (cbegin== 0) break;
	}
	return null;
}

function setCookie(name, value, days, path, domain, secure) 
{
	var expires = null;
	
	if(days)
	{
		expires = new Date();
		var theDay = expires.getDate();
		theDay = theDay + days;
		expires.setDate(theDay);
	}
	
	var ciacho = name + "=" + escape(value) +
        ((expires) ? "; expires=" + expires.toGMTString() : "") +
        ((path) ? "; path=" + path : "") +
        ((domain) ? "; domain=" + domain : "") +
        ((secure) ? "; secure" : "");
	
    document.cookie = ciacho;
}

/* obiekt zakladek TabStrip */
function TabStrip(id, tabsCount)
{
	this.selected = id;
	this.tabsCount = tabsCount;
	
	this.renderTabs(this.selected);
}

TabStrip.prototype.renderTabs = function(selected)
{
	for(var i=0; i < this.tabsCount; i++)
	{
		if(i == selected)
			this.setActive(i);
		else
			this.setInactive(i);
	}
}

TabStrip.prototype.setActive = function(id)
{
	findObj('TabStrip_'+id).style.display = '';
	findObj('TabStripHeader_'+id).className = 'TabStripActive';
	setCookie('TabStrip_activeTab', id);
}

TabStrip.prototype.setInactive = function(id)
{
	findObj('TabStrip_'+id).style.display = 'none';
	findObj('TabStripHeader_'+id).className = 'TabStripInactive';
}

TabStrip.prototype.showTab = function(id)
{
	this.renderTabs(id);
}

var EditoCalendar = new Object();

/* wywolanie kalendarza */
EditoCalendar.showCalendar = function(obj, field, btn)
{
    Calendar.setup({
        inputField		:	field,
        ifFormat		:	"%Y-%m-%d",
        button			:	btn,
        singleClick		:	true,
		align			:	"Lt"
    });
	obj.onclick();
	
	return false;
}

/* bannery */
var EditoBannery = new Object();
EditoBannery.show = function(bannerList, kontener, mode, idBloku)
{
	if(mode == 'all')
	{
		for(bannerIndex in bannerList)
		{
			var cBanner = bannerList[bannerIndex];
			EditoBannery.showElement(kontener, cBanner);
		}
	}
	else if(mode == 'single_view_popup' && getCookie(kontener) == 1)
	{
		return;
	}
	else if(bannerList.length > 0)
	{
		// wylosuj banner z listy
		var randomIndex = Math.floor(Math.random() * bannerList.length);
		var cBanner = bannerList[randomIndex];
		// ustawianie ciacha jezeli popup ma sie pokazac tylko 1 raz
		if(mode == 'single_view_popup')
			setCookie(kontener, 1);
		EditoBannery.showElement(kontener, cBanner);
	}
}

EditoBannery.showElement = function(kontener, cBanner)
{     
	var swfParams = {
				  menu: "false",
				  quality: "high",
				  wmode: "transparent"
				};
				
	switch( cBanner.params.type )
	{
		case 'flash':
		
			var box = Math.floor(Math.random()*1000);
			$("#"+kontener).append('<div class="obiekt" id="' + kontener + box + '"></div>');
			
			swfobject.embedSWF(cBanner.file, kontener + box, cBanner.width, cBanner.height, "9.0.124", base_href + "flash/expressinstall.swf", {}, swfParams);
		break;
		
		case 'flash_link':
		
			var box = Math.floor(Math.random()*1000);
			$("#"+kontener).append('<div style="position: relative; width: ' + cBanner.width + 'px; height: ' + cBanner.height + 'px; text-align: left; margin: 0 auto;"><a href="/'+ cBanner.params.link +'" target="'+cBanner.params.target+'" class="mediaMaska" style="height: '+cBanner.height+'px;"></a><div id="' + kontener + box + '"></div></div>');
			
			var flashvars = {
				  alink1: cBanner.params.link,
				  atar1: cBanner.params.target
				};
			swfobject.embedSWF(cBanner.file + "?alink1=" + cBanner.params.link + "&amp;atar1=" + cBanner.params.target, kontener + box, cBanner.width, cBanner.height, "9.0.124", base_href + "flash/expressinstall.swf", flashvars, swfParams);
			
		break;
		
		case 'flash_popup':
			EditoStart.Add( function()
				{
					EditoPopup.Popup(cBanner.file, cBanner.params.link, cBanner.params.target, cBanner.width, cBanner.height, 'popup_flash', cBanner.params.popup_id, cBanner.params.popup_szablon, cBanner.params.popup_padding);
				}
			);
		break;
		
		case 'obrazek':    
			$("#"+kontener).append('<div class="obiekt"><img src="' + cBanner.file + '" width="' + cBanner.width + '" height="' + cBanner.height + '" alt="'+ cBanner.alt + '" border="0" /></div>');
		break;
		
		case 'obrazek_link':     
			$("#"+kontener).append('<div class="obiekt"><a href="' + cBanner.params.link + '" target="' + cBanner.params.target + '" rel="nofollow"><img src="' + cBanner.file + '" width="' + cBanner.width + '" height="' + cBanner.height + '" alt="'+ cBanner.alt + '" border="0" /></a></div>');
		break;
		case 'obrazek_popup':
			EditoStart.Add( function()
				{
					EditoPopup.Popup(cBanner.file, cBanner.params.link, cBanner.params.target, cBanner.width, cBanner.height, 'popup_obrazek', cBanner.params.popup_id, cBanner.params.popup_szablon, cBanner.params.popup_padding);
				}
			);
		break;
		
		case 'script':
			$("#"+kontener).append(cBanner.script);
		break;
	}
}

function showWin(src, w, h, title)
{
	$('#PopupDiv').css("height", document.body.clientHeight + "px");
	$('#PopupDiv #PopupContent').css("width", w);
	$('#PopupDiv #PopupContent').css("height", h);
	
	if($('#PopupDiv #PopupContent').find('#start').length == 0)
	{
		var content = '<table id="PopUp" class="PopUp" cellspacing="0" cellpadding="0" border="0">'
		+'					<tr>'
		+'						<td colspan="3" class="TitleBar">'
		+'							<table width="100%" cellspacing="0" cellpadding="0" border="0">'
		+'								<tr>'
		+'									<td class="btl">&nbsp;</td>'
		+'									<td class="bt"><span class="Title"></span></td>'
		+'									<td class="btc"><a href="javascript: void(hideWin());"><img src="/admin/Data/Images/popup/BtnClose.gif" width="16" height="16" border="0" class="Close" /></a></td>'
		+'									<td class="btr">&nbsp;</td>'
		+'								</tr>'
		+'							</table>'
		+'						</td>'
		+'					</tr>'
		+'					<tr>'
		+'						<td class="b bl">&nbsp;</td>'
		+'						<td class="bg"><div style="width: 100%; height:' + h + 'px; position: relative;">'
		+'							<div id="PopupLoading" style="width: 100%; height: 100%; background-color: #ffffff; position: absolute; border: 1px solid #888888;">'
		+'								<table border="0" style="width: 100%; height: 100%;">'
		+'									<tr>'
		+'										<td align="center" valign="middle">'
		+'											<img src="/admin/Data/Images/bigrotation.gif" border="0">'
		+'										</td>'
		+'									</tr>'
		+'								</table>'
		+'							</div>'
		+'							<iframe src="/szablony/blank.html" name="start" id="start" width="100%" height="100%" style="border: 1px solid #888888; background-color: #ffffff;" frameborder="0" marginheight="0" marginwidth="0" scrolling="auto"></iframe></div>'
		+'						</td>'
		+'						<td class="b br">&nbsp;</td>'
		+'					</tr>'
		+'					<tr>'
		+'						<td class="b bbl">&nbsp;</td>'
		+'						<td class="b bb">&nbsp;</td>'
		+'						<td class="b bbr">&nbsp;</td>'
		+'					</tr>'
		+'				</table>';
		
		$('#PopupDiv #PopupContent').append(content);
	}
	if(title != undefined) $('.PopUp .Title').html(title);
	$('#PopupLoading').show();
	$('#PopupDiv').show();
	window.frames['start'].location.href = src + '&ispopup=1';
	return window.frames['start'];
}

function hideWin()
{
	$('.PopUp .Title').html('');
	$('#PopupDiv').hide();
	window.frames['start'].location.href = '/szablony/blank.html';
}

jQuery.fn.extend( {
    showAjaxIndicator: function() {
    	var div = $('<div class="jq_progress2"></div>');
        this.before(div);

        div.css('width', this.get(0).offsetWidth + 'px');
        div.css('height', this.get(0).offsetHeight + 'px');
        div.css('top', this.get(0).offsetTop + 'px');
        div.css('left', this.get(0).offsetLeft + 'px');
    }
});

jQuery.fn.extend( {
    hideAjaxIndicator: function() {
        $(this).prev('div.jq_progress2').remove();
    }
});

function addBookmarkForBrowser(msg)
{
	if (window.sidebar)
	{ // Mozilla Firefox Bookmark
		window.sidebar.addPanel(document.title, document.location.href,"");
	} else if( window.external )
	{ // IE Favorite
		window.external.AddFavorite( document.location.href, document.title);
	}
	else if(window.opera && window.print)
	{ // Opera Hotlist
		alert(msg);
	}
	return false;
}

/*SWFObject v2.1*/
var swfobject=function(){var b="undefined",Q="object",n="Shockwave Flash",p="ShockwaveFlash.ShockwaveFlash",P="application/x-shockwave-flash",m="SWFObjectExprInst",j=window,K=document,T=navigator,o=[],N=[],i=[],d=[],J,Z=null,M=null,l=null,e=false,A=false;var h=function(){var v=typeof K.getElementById!=b&&typeof K.getElementsByTagName!=b&&typeof K.createElement!=b,AC=[0,0,0],x=null;if(typeof T.plugins!=b&&typeof T.plugins[n]==Q){x=T.plugins[n].description;if(x&&!(typeof T.mimeTypes!=b&&T.mimeTypes[P]&&!T.mimeTypes[P].enabledPlugin)){x=x.replace(/^.*\s+(\S+\s+\S+$)/,"$1");AC[0]=parseInt(x.replace(/^(.*)\..*$/,"$1"),10);AC[1]=parseInt(x.replace(/^.*\.(.*)\s.*$/,"$1"),10);AC[2]=/r/.test(x)?parseInt(x.replace(/^.*r(.*)$/,"$1"),10):0}}else{if(typeof j.ActiveXObject!=b){var y=null,AB=false;try{y=new ActiveXObject(p+".7")}catch(t){try{y=new ActiveXObject(p+".6");AC=[6,0,21];y.AllowScriptAccess="always"}catch(t){if(AC[0]==6){AB=true}}if(!AB){try{y=new ActiveXObject(p)}catch(t){}}}if(!AB&&y){try{x=y.GetVariable("$version");if(x){x=x.split(" ")[1].split(",");AC=[parseInt(x[0],10),parseInt(x[1],10),parseInt(x[2],10)]}}catch(t){}}}}var AD=T.userAgent.toLowerCase(),r=T.platform.toLowerCase(),AA=/webkit/.test(AD)?parseFloat(AD.replace(/^.*webkit\/(\d+(\.\d+)?).*$/,"$1")):false,q=false,z=r?/win/.test(r):/win/.test(AD),w=r?/mac/.test(r):/mac/.test(AD);/*@cc_on q=true;@if(@_win32)z=true;@elif(@_mac)w=true;@end@*/return{w3cdom:v,pv:AC,webkit:AA,ie:q,win:z,mac:w}}();var L=function(){if(!h.w3cdom){return}f(H);if(h.ie&&h.win){try{K.write("<script id=__ie_ondomload defer=true src=//:><\/script>");J=C("__ie_ondomload");if(J){I(J,"onreadystatechange",S)}}catch(q){}}if(h.webkit&&typeof K.readyState!=b){Z=setInterval(function(){if(/loaded|complete/.test(K.readyState)){E()}},10)}if(typeof K.addEventListener!=b){K.addEventListener("DOMContentLoaded",E,null)}R(E)}();function S(){if(J.readyState=="complete"){J.parentNode.removeChild(J);E()}}function E(){if(e){return}if(h.ie&&h.win){var v=a("span");try{var u=K.getElementsByTagName("body")[0].appendChild(v);u.parentNode.removeChild(u)}catch(w){return}}e=true;if(Z){clearInterval(Z);Z=null}var q=o.length;for(var r=0;r<q;r++){o[r]()}}function f(q){if(e){q()}else{o[o.length]=q}}function R(r){if(typeof j.addEventListener!=b){j.addEventListener("load",r,false)}else{if(typeof K.addEventListener!=b){K.addEventListener("load",r,false)}else{if(typeof j.attachEvent!=b){I(j,"onload",r)}else{if(typeof j.onload=="function"){var q=j.onload;j.onload=function(){q();r()}}else{j.onload=r}}}}}function H(){var t=N.length;for(var q=0;q<t;q++){var u=N[q].id;if(h.pv[0]>0){var r=C(u);if(r){N[q].width=r.getAttribute("width")?r.getAttribute("width"):"0";N[q].height=r.getAttribute("height")?r.getAttribute("height"):"0";if(c(N[q].swfVersion)){if(h.webkit&&h.webkit<312){Y(r)}W(u,true)}else{if(N[q].expressInstall&&!A&&c("6.0.65")&&(h.win||h.mac)){k(N[q])}else{O(r)}}}}else{W(u,true)}}}function Y(t){var q=t.getElementsByTagName(Q)[0];if(q){var w=a("embed"),y=q.attributes;if(y){var v=y.length;for(var u=0;u<v;u++){if(y[u].nodeName=="DATA"){w.setAttribute("src",y[u].nodeValue)}else{w.setAttribute(y[u].nodeName,y[u].nodeValue)}}}var x=q.childNodes;if(x){var z=x.length;for(var r=0;r<z;r++){if(x[r].nodeType==1&&x[r].nodeName=="PARAM"){w.setAttribute(x[r].getAttribute("name"),x[r].getAttribute("value"))}}}t.parentNode.replaceChild(w,t)}}function k(w){A=true;var u=C(w.id);if(u){if(w.altContentId){var y=C(w.altContentId);if(y){M=y;l=w.altContentId}}else{M=G(u)}if(!(/%$/.test(w.width))&&parseInt(w.width,10)<310){w.width="310"}if(!(/%$/.test(w.height))&&parseInt(w.height,10)<137){w.height="137"}K.title=K.title.slice(0,47)+" - Flash Player Installation";var z=h.ie&&h.win?"ActiveX":"PlugIn",q=K.title,r="MMredirectURL="+j.location+"&MMplayerType="+z+"&MMdoctitle="+q,x=w.id;if(h.ie&&h.win&&u.readyState!=4){var t=a("div");x+="SWFObjectNew";t.setAttribute("id",x);u.parentNode.insertBefore(t,u);u.style.display="none";var v=function(){u.parentNode.removeChild(u)};I(j,"onload",v)}U({data:w.expressInstall,id:m,width:w.width,height:w.height},{flashvars:r},x)}}function O(t){if(h.ie&&h.win&&t.readyState!=4){var r=a("div");t.parentNode.insertBefore(r,t);r.parentNode.replaceChild(G(t),r);t.style.display="none";var q=function(){t.parentNode.removeChild(t)};I(j,"onload",q)}else{t.parentNode.replaceChild(G(t),t)}}function G(v){var u=a("div");if(h.win&&h.ie){u.innerHTML=v.innerHTML}else{var r=v.getElementsByTagName(Q)[0];if(r){var w=r.childNodes;if(w){var q=w.length;for(var t=0;t<q;t++){if(!(w[t].nodeType==1&&w[t].nodeName=="PARAM")&&!(w[t].nodeType==8)){u.appendChild(w[t].cloneNode(true))}}}}}return u}function U(AG,AE,t){var q,v=C(t);if(v){if(typeof AG.id==b){AG.id=t}if(h.ie&&h.win){var AF="";for(var AB in AG){if(AG[AB]!=Object.prototype[AB]){if(AB.toLowerCase()=="data"){AE.movie=AG[AB]}else{if(AB.toLowerCase()=="styleclass"){AF+=' class="'+AG[AB]+'"'}else{if(AB.toLowerCase()!="classid"){AF+=" "+AB+'="'+AG[AB]+'"'}}}}}var AD="";for(var AA in AE){if(AE[AA]!=Object.prototype[AA]){AD+='<param name="'+AA+'" value="'+AE[AA]+'" />'}}v.outerHTML='<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"'+AF+">"+AD+"</object>";i[i.length]=AG.id;q=C(AG.id)}else{if(h.webkit&&h.webkit<312){var AC=a("embed");AC.setAttribute("type",P);for(var z in AG){if(AG[z]!=Object.prototype[z]){if(z.toLowerCase()=="data"){AC.setAttribute("src",AG[z])}else{if(z.toLowerCase()=="styleclass"){AC.setAttribute("class",AG[z])}else{if(z.toLowerCase()!="classid"){AC.setAttribute(z,AG[z])}}}}}for(var y in AE){if(AE[y]!=Object.prototype[y]){if(y.toLowerCase()!="movie"){AC.setAttribute(y,AE[y])}}}v.parentNode.replaceChild(AC,v);q=AC}else{var u=a(Q);u.setAttribute("type",P);for(var x in AG){if(AG[x]!=Object.prototype[x]){if(x.toLowerCase()=="styleclass"){u.setAttribute("class",AG[x])}else{if(x.toLowerCase()!="classid"){u.setAttribute(x,AG[x])}}}}for(var w in AE){if(AE[w]!=Object.prototype[w]&&w.toLowerCase()!="movie"){F(u,w,AE[w])}}v.parentNode.replaceChild(u,v);q=u}}}return q}function F(t,q,r){var u=a("param");u.setAttribute("name",q);u.setAttribute("value",r);t.appendChild(u)}function X(r){var q=C(r);if(q&&(q.nodeName=="OBJECT"||q.nodeName=="EMBED")){if(h.ie&&h.win){if(q.readyState==4){B(r)}else{j.attachEvent("onload",function(){B(r)})}}else{q.parentNode.removeChild(q)}}}function B(t){var r=C(t);if(r){for(var q in r){if(typeof r[q]=="function"){r[q]=null}}r.parentNode.removeChild(r)}}function C(t){var q=null;try{q=K.getElementById(t)}catch(r){}return q}function a(q){return K.createElement(q)}function I(t,q,r){t.attachEvent(q,r);d[d.length]=[t,q,r]}function c(t){var r=h.pv,q=t.split(".");q[0]=parseInt(q[0],10);q[1]=parseInt(q[1],10)||0;q[2]=parseInt(q[2],10)||0;return(r[0]>q[0]||(r[0]==q[0]&&r[1]>q[1])||(r[0]==q[0]&&r[1]==q[1]&&r[2]>=q[2]))?true:false}function V(v,r){if(h.ie&&h.mac){return}var u=K.getElementsByTagName("head")[0],t=a("style");t.setAttribute("type","text/css");t.setAttribute("media","screen");if(!(h.ie&&h.win)&&typeof K.createTextNode!=b){t.appendChild(K.createTextNode(v+" {"+r+"}"))}u.appendChild(t);if(h.ie&&h.win&&typeof K.styleSheets!=b&&K.styleSheets.length>0){var q=K.styleSheets[K.styleSheets.length-1];if(typeof q.addRule==Q){q.addRule(v,r)}}}function W(t,q){var r=q?"visible":"hidden";if(e&&C(t)){C(t).style.visibility=r}else{V("#"+t,"visibility:"+r)}}function g(s){var r=/[\\\"<>\.;]/;var q=r.exec(s)!=null;return q?encodeURIComponent(s):s}var D=function(){if(h.ie&&h.win){window.attachEvent("onunload",function(){var w=d.length;for(var v=0;v<w;v++){d[v][0].detachEvent(d[v][1],d[v][2])}var t=i.length;for(var u=0;u<t;u++){X(i[u])}for(var r in h){h[r]=null}h=null;for(var q in swfobject){swfobject[q]=null}swfobject=null})}}();return{registerObject:function(u,q,t){if(!h.w3cdom||!u||!q){return}var r={};r.id=u;r.swfVersion=q;r.expressInstall=t?t:false;N[N.length]=r;W(u,false)},getObjectById:function(v){var q=null;if(h.w3cdom){var t=C(v);if(t){var u=t.getElementsByTagName(Q)[0];if(!u||(u&&typeof t.SetVariable!=b)){q=t}else{if(typeof u.SetVariable!=b){q=u}}}}return q},embedSWF:function(x,AE,AB,AD,q,w,r,z,AC){if(!h.w3cdom||!x||!AE||!AB||!AD||!q){return}AB+="";AD+="";if(c(q)){W(AE,false);var AA={};if(AC&&typeof AC===Q){for(var v in AC){if(AC[v]!=Object.prototype[v]){AA[v]=AC[v]}}}AA.data=x;AA.width=AB;AA.height=AD;var y={};if(z&&typeof z===Q){for(var u in z){if(z[u]!=Object.prototype[u]){y[u]=z[u]}}}if(r&&typeof r===Q){for(var t in r){if(r[t]!=Object.prototype[t]){if(typeof y.flashvars!=b){y.flashvars+="&"+t+"="+r[t]}else{y.flashvars=t+"="+r[t]}}}}f(function(){U(AA,y,AE);if(AA.id==AE){W(AE,true)}})}else{if(w&&!A&&c("6.0.65")&&(h.win||h.mac)){A=true;W(AE,false);f(function(){var AF={};AF.id=AF.altContentId=AE;AF.width=AB;AF.height=AD;AF.expressInstall=w;k(AF)})}}},getFlashPlayerVersion:function(){return{major:h.pv[0],minor:h.pv[1],release:h.pv[2]}},hasFlashPlayerVersion:c,createSWF:function(t,r,q){if(h.w3cdom){return U(t,r,q)}else{return undefined}},removeSWF:function(q){if(h.w3cdom){X(q)}},createCSS:function(r,q){if(h.w3cdom){V(r,q)}},addDomLoadEvent:f,addLoadEvent:R,getQueryParamValue:function(v){var u=K.location.search||K.location.hash;if(v==null){return g(u)}if(u){var t=u.substring(1).split("&");for(var r=0;r<t.length;r++){if(t[r].substring(0,t[r].indexOf("="))==v){return g(t[r].substring((t[r].indexOf("=")+1)))}}}return""},expressInstallCallback:function(){if(A&&M){var q=C(m);if(q){q.parentNode.replaceChild(M,q);if(l){W(l,true);if(h.ie&&h.win){M.style.display="block"}}M=null;l=null;A=false}}}}}();

/* Dynamic Form */
$(document).ready(function()
{
	var panels = $('.df-main');
	panels.hide().eq(0).show();
	
	if(panels.find('.df-button-next'))
		panels.find('.df-button-prev:last').show();
	
	panels.eq(0).find('.df-button-prev').hide();
	
	panels.find('.df-button-prev').click(function()
	{
		panels.filter(':visible').hide().prev().show();
	});
	panels.find('.df-button-next').click(function()
	{
		panels.filter(':visible').hide().next().show();
	});
});

function popup ()
{
	var html = '\'';
	html += '<div id="popup-box">';
	html +=		'<div class="overlay" style="filter: alpha(opacity=80);"></div>';
	html +=		'<div class="popup-content">';
	html +=			'<div class="box1">';
	html +=				'<div class="box1-top"><div></div></div>';
	html +=				'<div class="box1-middle" id="popup-content">';
	html +=				'<a id="btnClose"><img src="/szablony/default/images/lightbox-btn-close.gif"></a>';
	html +=				'</div>';
	html +=				'<div class="box1-bottom"><div></div></div>';
	html +=			'</div>';
	html +=		'</div>';
	html += '</div>\'';

	$("body").append(html);
	$("#popup-box .overlay").fadeIn(300, function(){});

	$("#popup-box .overlay").click(function() {
		hidePopup();
	});
	$("#popup-box .overlay").click(function() {
		hidePopup();
	});
	$("#popup-box #btnClose").click(function() {
		hidePopup();
	});
}

function addPopupContent (data)
{
	$("#popup-content").append(data);
}

function showPopup ()
{
	$(".popup-content").fadeIn(300, function(){});
}

function hidePopup (time)
{
	if (time)
	{
		setTimeout(function() {
			$("#popup-box").remove();
		}, 1500);
	}
	else
	{
		$("#popup-box").remove();
	}
}
function showInfo (info)
{
	$(".popup-content #js-info").html(info);
}

/* twoja sygestia */
$(document).ready(function()
{
	$("#suggestion-block").click(function()
	{
		popup();
		link = $(this).attr('href');
		$.ajax({
			url: link,
			type: "POST",
			success: function(data)
			{
				showPopup();
				addPopupContent(data);
			}
		});
	});

	$("#suggestion-button").live("click", function()
	{
		link = $('form[name=suggestion_form]').attr('action');

		var email = $('form[name=suggestion_form] input[name=email]').val();
		var subject = $('form[name=suggestion_form] input[name=temat]').val();
		var text = $('form[name=suggestion_form] textarea[name=tresc]').val();

		$.ajax({
			url: link,
			type: "POST",
			dataType: "json",
			data: "email="+email+"&subject="+subject+"&text="+text,
			success: function(data)
			{
				$('form[name=suggestion_form] *').removeClass('errorClass');
				showInfo(data['info']);

				if(!data['error'])
				{
					$('form[name=suggestion_form] #suggestion-button').removeAttr("id");
					hidePopup(true);
				}
				else
				{
					$.each(data['error'], function(key, value) {
					  selectField(value);
					});
				}

			}
		});
	});
});

function selectField(name)
{
	$('form[name=suggestion_form] [name='+name+']').addClass('errorClass');
}