
var EditoPopup = new Object();
EditoPopup.BorderSize = 1;
EditoPopup.IcoCloseHeight = 26;
EditoPopup.PaddingWidth = 10;
EditoPopup.PaddingHeight = 10;

EditoPopup.Popup = function(popup_src,popup_link,popup_target,popup_width,popup_height,type,popup_id,popup_szablon,popup_padding)
{	
	if (type == 'popup_flash')
	{
		var html = '';
		html += '<div id="EditoPopup$Overlay'+popup_id+'" class="PopupOverlay" style="display:none;"></div>';
		html += '<iframe id="EditoPopup$Background'+popup_id+'" style="display:none;"></iframe>';
		html += '<table cellspacing="0" cellpadding="0" border="0" id="EditoPopup$Panel'+popup_id+'" class="Popup" style="display:none;">';
		html += '	<tr>';
		html += '		<td id="EditoPopup$Container'+popup_id+'" class="ImageContainer">';
		html += '			<div onclick="EditoPopupClose('+popup_id+')" id="EditoPopup$IcoClose'+popup_id+'" class="IcoClose"></div>';
		html += '			<div id="EditoPopup$Preview'+popup_id+'" class="Preview">';
		html += '				<object';
		html += '					classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"';
		html += '					codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0"';
		html += '					width="'+popup_width+'" height="'+popup_height+'">';
		html += '					<param name="movie" value="../../'+popup_src+'?alink1='+popup_link+'&amp;atar1='+popup_target+'" />';
		html += '					<param name="quality" value="high" />';
		html += '					<param name="flashvars" value="alink1='+popup_link+'&amp;atar1='+popup_target+'" />';
		html += '					<param name="wmode" value="transparent" />';
		html += '					<embed'; 
		html += '						src="../../'+popup_src+'?alink1='+popup_link+'&amp;atar1='+popup_target+'"';
		html += '						flashvars = "alink1='+popup_link+'&amp;atar1='+popup_target+'"';
		html += '						quality="high"'; 
		html += '						pluginspage="http://www.macromedia.com/go/getflashplayer"'; 
		html += '						type="application/x-shockwave-flash"'; 
		html += '						wmode="transparent"';
		html += '						width="'+popup_width+'"';
		html += '						height="'+popup_height+'">';
		html += '					</embed>';
		html += '				</object>';
		html += '			</div>';
		html += '			<div id="EditoPopup$Loader'+popup_id+'" class="Loader"></div>';
		html += '		</td>';
		html += '	</tr>';
		html += '</table>';
		
	}
	else if (type == 'popup_obrazek')
	{
		var html = '';
		html += '<div id="EditoPopup$Overlay'+popup_id+'" class="PopupOverlay" style="display:none;"></div>';
		html += '<iframe id="EditoPopup$Background'+popup_id+'" style="display:none;"></iframe>';
		html += '<table cellspacing="0" cellpadding="0" border="0" id="EditoPopup$Panel'+popup_id+'" class="Popup" style="display:none;">';
		html += '	<tr>';
		html += '		<td id="EditoPopup$Container'+popup_id+'" class="ImageContainer">';
		html += '			<div onclick="EditoPopupClose('+popup_id+')" id="EditoPopup$IcoClose'+popup_id+'" class="IcoClose"></div>';
		html += '			<a id="EditoPopup$ImgHref'+popup_id+'"><img id="EditoPopup$Preview'+popup_id+'" class="Preview"/></a>';
		html += '			<div id="EditoPopup$Loader'+popup_id+'" class="Loader"></div>';
		html += '		</td>';
		html += '	</tr>';
		html += '</table>';
	}
	
	var body = document.getElementsByTagName("body")[0];
	var span = document.createElement("span");
	span.innerHTML = html;
	body.appendChild(span);
	
	EditoPopup.Show(popup_src,popup_link,popup_target,popup_width,popup_height,type,popup_id,popup_szablon,popup_padding);
}

EditoPopup.Item = function(id)
{
	return document.getElementById("EditoPopup$" + id);
}

EditoPopup.Screen = function()
{
	if( typeof( window.innerWidth ) == 'number' )
	{
		//Non-IE
		return [window.innerWidth, window.innerHeight];
	}
	else if( document.documentElement && ( document.documentElement.clientWidth || document.documentElement.clientHeight ) )
	{
		//IE 6+ in 'standards compliant mode'
		return [document.documentElement.clientWidth, document.documentElement.clientHeight];
	}
	else if( document.body && ( document.body.clientWidth || document.body.clientHeight ) )
	{
		//IE 4 compatible
		return [document.body.clientWidth, document.body.clientHeight];
	}
}

EditoPopup.Show = function(popup_src,popup_link,popup_target,popup_width,popup_height,type,popup_id,popup_szablon,popup_padding)
{
	EditoPopup.Item("Preview"+popup_id).style.display = "none";
	EditoPopup.Item("IcoClose"+popup_id).style.display = "none";
	EditoPopup.Item("Loader"+popup_id).style.display = "";
	EditoPopup.Item("Container"+popup_id).style.width = "500px";
	EditoPopup.Item("Container"+popup_id).style.height = "400px";
	EditoPopup.Item("Panel"+popup_id).style.width = "500px";
	EditoPopup.Item("Panel"+popup_id).style.height = "400px";
	EditoPopup.Item("Panel"+popup_id).style.position = "absolute";
	EditoPopup.Item("Panel"+popup_id).style.display = "";
	
	EditoPopup.ChangePosition(popup_id,popup_szablon,popup_padding);
	
	var img = new Image();
	EditoPopup.ImageLoad(popup_src,popup_link,popup_target,popup_width,popup_height,type,popup_id,popup_szablon,popup_padding);
}

EditoPopup.ChangePosition = function(popup_id,popup_szablon,popup_padding)
{
	var screen = EditoPopup.Screen();
	
	var offsetWidth = parseInt(EditoPopup.Item("Panel"+popup_id).style.width) + EditoPopup.PaddingWidth + 4*EditoPopup.BorderSize;
	var offsetHeight = parseInt(EditoPopup.Item("Panel"+popup_id).style.height) + EditoPopup.PaddingHeight + EditoPopup.IcoCloseHeight + 4*EditoPopup.BorderSize;
	
	if (popup_szablon == 1)
	{
		var left = popup_padding;
		var top = popup_padding;
	}
	else if (popup_szablon == 2)
	{
		var left = ((screen[0] - offsetWidth) / 2);
		var top = popup_padding;
	}
	else if (popup_szablon == 3)
	{
		var left = screen[0] - offsetWidth - popup_padding;
		var top = popup_padding;
	}
	else if (popup_szablon == 4)
	{
		var left = popup_padding;
		var top = ((screen[1] - offsetHeight) / 2);
	}
	else if (popup_szablon == 5)
	{
		var left = ((screen[0] - offsetWidth) / 2);
		var top = ((screen[1] - offsetHeight) / 2);
	}
	else if (popup_szablon == 6)
	{
		var left = screen[0] - offsetWidth - popup_padding;
		var top = ((screen[1] - offsetHeight) / 2);
	}
	else if (popup_szablon == 7)
	{
		var left = popup_padding;
		var top = screen[1] - offsetHeight - popup_padding;
	}
	else if (popup_szablon == 8)
	{
		var left = ((screen[0] - offsetWidth) / 2);
		var top = screen[1] - offsetHeight - popup_padding;
	}
	else if (popup_szablon == 9)
	{
		var left = screen[0] - offsetWidth - popup_padding;
		var top = screen[1] - offsetHeight - popup_padding;
	}
	else
	{
		var left = ((screen[0] - offsetWidth) / 2);
		var top = ((screen[1] - offsetHeight) / 2);
	}
	
	EditoPopup.Item("Panel"+popup_id).style.zIndex = "100";
	EditoPopup.Item("Panel"+popup_id).style.left = ((left > 0) ? left : 0) + "px";
	EditoPopup.Item("Panel"+popup_id).style.top = ((top > 0) ? top : 0) + "px";
	
	var overlayHeight = document.body.offsetHeight;
	if(overlayHeight < screen[1])
	{
		overlayHeight = screen[1];
	}
	if(parseInt(EditoPopup.Item("Panel"+popup_id).style.top) + offsetHeight > overlayHeight)
	{
		overlayHeight = parseInt(EditoPopup.Item("Panel"+popup_id).style.top) + offsetHeight;
	}
	
	if(!((document.getElementById && !document.all) || window.opera))
	{
		EditoPopup.Item("Background"+popup_id).style.position = "absolute";
		EditoPopup.Item("Background"+popup_id).style.zIndex = "95";
		EditoPopup.Item("Background"+popup_id).style.left = EditoPopup.Item("Panel"+popup_id).style.left;
		EditoPopup.Item("Background"+popup_id).style.top = EditoPopup.Item("Panel"+popup_id).style.top;
		EditoPopup.Item("Background"+popup_id).style.height = offsetHeight;
		EditoPopup.Item("Background"+popup_id).style.width = offsetWidth;
		EditoPopup.Item("Background"+popup_id).style.display = "";
	}
	
	EditoPopup.Item("Overlay"+popup_id).style.position = "absolute";
	EditoPopup.Item("Overlay"+popup_id).style.zIndex = "90";
	EditoPopup.Item("Overlay"+popup_id).style.left = "0px";
	EditoPopup.Item("Overlay"+popup_id).style.top = "0px";
	EditoPopup.Item("Overlay"+popup_id).style.height = overlayHeight + EditoPopup.PaddingHeight + EditoPopup.IcoCloseHeight + 4*EditoPopup.BorderSize + "px";
	EditoPopup.Item("Overlay"+popup_id).style.display = "";
}

EditoPopup.ImageLoad = function(popup_src,popup_link,popup_target,popup_width,popup_height,type,popup_id,popup_szablon,popup_padding)
{
	EditoPopup.Item("Background"+popup_id).style.display = "none";
	EditoPopup.Item("Panel"+popup_id).style.width = "";
	EditoPopup.Item("Panel"+popup_id).style.height = "";
		
	EditoPopup.Item("Container"+popup_id).style.width = parseInt(popup_width) + "px";
	EditoPopup.Item("Container"+popup_id).style.height = parseInt(popup_height) + "px";
	EditoPopup.Item("Panel"+popup_id).style.width = parseInt(popup_width) + "px";
	EditoPopup.Item("Panel"+popup_id).style.height = parseInt(popup_height) + "px";
	
	EditoPopup.Item("Loader"+popup_id).style.display = "none";
	
	EditoPopup.Item("Preview"+popup_id).style.display = "";
	EditoPopup.Item("IcoClose"+popup_id).style.display = "";
	
	if (type == 'popup_obrazek')
	{
		EditoPopup.Item("Preview"+popup_id).src = popup_src;
		EditoPopup.Item("ImgHref"+popup_id).href = popup_link;
		EditoPopup.Item("ImgHref"+popup_id).target = popup_target;
	}
	
	EditoPopup.ChangePosition(popup_id,popup_szablon,popup_padding);
	
}

function EditoPopupClose(popup_id)
{
	EditoPopup.Item("Preview"+popup_id).style.display = "none";
	EditoPopup.Item("IcoClose"+popup_id).style.display = "none";
	EditoPopup.Item("Panel"+popup_id).style.display = "none";
	EditoPopup.Item("Overlay"+popup_id).style.display = "none";
	EditoPopup.Item("Background"+popup_id).style.display = "none";
}
