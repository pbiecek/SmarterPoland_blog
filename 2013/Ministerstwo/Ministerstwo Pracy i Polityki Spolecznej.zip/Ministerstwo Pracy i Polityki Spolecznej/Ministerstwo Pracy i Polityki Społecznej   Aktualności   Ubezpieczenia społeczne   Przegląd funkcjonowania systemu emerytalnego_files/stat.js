function checkCookies()
{
	var CookieEnabled = false;
	
	document.cookie = "CookieTest=Enabled; path=/";
	
	var pos = document.cookie.indexOf("CookieTest=");
	if (pos != -1)
	{
		var start = pos + 11;
		var end = document.cookie.indexOf(";", start);
		if (end == -1)
		{
			end = document.cookie.length;
		}
		var value = document.cookie.substring(start,end);
		
		CookieEnabled = unescape(value);
	}
	
	return (CookieEnabled == "Enabled") ? true : false;
}

function detectFlash()
{
	var flashversion = 0;
	
	if (navigator.plugins && navigator.plugins.length)
	{
		x = navigator.plugins["Shockwave Flash"];
		if (x && x.description)
		{
			y = x.description;
			flashversion = y.charAt(y.indexOf('.')-1);
		}
	}
	else
	{
		for (var i=9; i>0; i--)
		{
			try
			{
				var flash = new ActiveXObject("ShockwaveFlash.ShockwaveFlash." + i);
				flashversion = i;
				break;
			}
			catch (e) { false; }
		}
	}
	
	return flashversion;
}

function editoStat()
{
	var url = '?date='+(new Date()).getTime();
	var scripts = document.getElementsByTagName("script");
	for(var i=0; i<scripts.length; i++)
	{
		var s = scripts[i];
		if(s.src && (result = s.src.match(/stat\.js\?(.+)$/)))
		{
			url += '&' + result[1];
			break;
		}
	}
	if (screen)
	{
		var s = screen;
		if (s.width) url += '&screen='+s.width+'x'+s.height;
		if (s.colorDepth) url += '&bits='+s.colorDepth;
	}
	url += '&flash='+detectFlash();
	if (navigator.javaEnabled()) url += '&java=1';
	if(typeof(window.top.document.referrer) != 'undefined')
	{
		url += '&ref='+escape(window.top.document.referrer).replace(/\+/g, '%2B').replace(/\"/g,'%22').replace(/\'/g, '%27');
	}
	url += '&url='+escape(window.top.location.href).replace(/\+/g, '%2B').replace(/\"/g,'%22').replace(/\'/g, '%27');
	
	return url;
}

if (checkCookies())
{
	var img = new Image();
	img.src = "/index.php/stat/" + editoStat();
}