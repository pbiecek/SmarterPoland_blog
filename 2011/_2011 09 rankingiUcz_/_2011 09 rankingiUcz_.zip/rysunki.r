 library(lattice)
library(latticeExtra)
library(quantreg)
library(splines)

mieszkaniaKWW2011 <-
     read.table("http://tofesi.mimuw.edu.pl/~cogito/smarterpoland/mieszkaniaKWW2011/mieszkaniaKWW2011.csv",
         row.names=NULL, sep=";", header=TRUE,
         colClasses=c("factor", "factor", "numeric", "numeric", "factor", "numeric", "numeric", "factor", "Date"))

# tylko dane z Wroclawia i do 100 m2
mieszkaniaKWW2011Wroclaw = mieszkaniaKWW2011[mieszkaniaKWW2011$miasto =="Wroclaw", ]
mieszkaniaKWW2011Wroclaw$dzielnica = factor(mieszkaniaKWW2011Wroclaw$dzielnica)
mieszkaniaKWW2011Wroclaw = mieszkaniaKWW2011Wroclaw[mieszkaniaKWW2011Wroclaw$powierzchnia<100, ]

# rys 1
png("mieszkaniaKWW2011Wroclaw1.png", 800, 600)
xyplot(cenam2~powierzchnia, groups=dzielnica, data=mieszkaniaKWW2011Wroclaw, type=c("smooth"), ylim=c(4500,9500), xlim=c(18,105), auto.key=list(columns=6, lwd=5, pch=19), lwd=4, pch=19, cex=0.2, xlab="powierzchnia [m^2]", ylab="srednia cena za m^2 [PLN]", main="Wroclaw")
dev.off()

# rys 2
png("mieszkaniaKWW2011Wroclaw2.png", 800, 600)
xyplot(I(cenam2 - 15*powierzchnia + 15*50)~data, groups=dzielnica, data=mieszkaniaKWW2011Wroclaw, type=c("smooth"), ylim=c(4500,9500), auto.key=list(columns=6, lwd=5, pch=19), lwd=4, pch=19, cex=0.2, xlab="data oferty", ylab="srednia cena za m^2 [PLN]", main="Wroclaw, mieszkanie 50m2")
dev.off()

# rys 3
png("mieszkaniaKWW2011Wroclaw3.png", 800, 600)
 tab = table(factor(format(mieszkaniaKWW2011Wroclaw$data, "%Y %m")), mieszkaniaKWW2011Wroclaw$dzielnica)
 tab2 = as.data.frame(tab)
 tab2$Var1 = as.Date(paste(tab2$Var1,"15"), "%Y %m %d")
  xyplot(Freq~Var1, groups=Var2, data=tab2, type="smooth", scales = list(y = list(log = TRUE)), xlab="data oferty", ylab="liczba ofert", lwd=4, auto.key=list(columns=6, lwd=5, pch=19), main="Wroclaw")
dev.off()

#
# dodajemy indeksy trzech grup, kawalerka, dwa-pokoje i 3-4 pokoje

attach(mieszkaniaKWW2011Wroclaw)
rodzaj = numeric(nrow(mieszkaniaKWW2011Wroclaw))
rodzaj[pokoi == 1 & powierzchnia >= 20 & powierzchnia <= 35] = 1
rodzaj[pokoi == 2 & powierzchnia >= 40 & powierzchnia <= 55] = 2
rodzaj[pokoi >= 3 & pokoi <= 4 & powierzchnia >= 60 & powierzchnia <= 80] = 3
detach(mieszkaniaKWW2011Wroclaw)

rodzaj[rodzaj==0] = NA
naz = c("kawalerka", "2 pokoje", "3-4 pokoje")
mieszkaniaKWW2011Wroclaw$rodzaj = factor(rodzaj, labels=naz)

png("mieszkaniaKWW2011Wroclaw4.png", 800, 600)
xyplot(cenam2~data|dzielnica, groups=rodzaj, mieszkaniaKWW2011Wroclaw, type=c("p","smooth"), cex=0.2, lwd=3, ylim=c(4000,10000), auto.key=list(columns=3, lwd=6), ylab="cena m^2", xlab="data", main="Wroclaw",
   panel = function(...) {
    params = list(...)
    kolory = trellis.par.get("superpose.symbol")$col
    for (id in 1:3) {
        df2 = subset(data.frame(params$x, params$y), as.character(params$groups[params$subscripts]) == naz[id])
        df2 = df2[order(df2[,1]),]
        panel.xyplot(df2[,1], df2[,2], type="smooth", lwd=1, col=kolory[id], family="gaussian", degree=1, span=0.5, lty=3)
        # przygotowanie danych
        df3 = data.frame(params.x=sort(unique(df2[,1])))
        df4 = rq(params.y~ns(params.x,4), data=df2, tau=c(0.25,0.5,0.75))$fitted.value
        df5 = data.frame(df2, df4)
        colnames(df5) = c("dat", "q1", "q5", "q9")
        # rysowanie przedzialow
        panel.xyplot(df5$dat, df5$q5, type="l", col=kolory[id], lwd=3)
      }
   })
dev.off()

mieszkaniaKWW2011Wroclaw2011 = mieszkaniaKWW2011Wroclaw[mieszkaniaKWW2011Wroclaw$data > as.Date("2011-01-01"),]
xscale.components.default10 = function(lim, ...) {
   tmp = xscale.components.default(lim=c(3000,14000),...)
   tmp$bottom$ticks$at = 2000*c(2:6)
   tmp$bottom$labels$at = 2000*c(2:6)
   tmp$bottom$labels$labels = as.character(2000*c(2:6))
   tmp
}
png("mieszkaniaKWW2011Wroclaw5.png", 800, 350)
bwplot(dzielnica~cenam2|rodzaj, data=mieszkaniaKWW2011Wroclaw2011, main="Wroclaw, ceny z 2011", xlab="cena m^2 [PLN]",
     xscale.components = xscale.components.default10,
     panel = function(...){
  panel.grid(v=-1,h=0, col="grey", lty=3)
  panel.bwplot(..., fill="lightblue1", pch=19, lwd=2 ,varwidth=T)
})
dev.off()
