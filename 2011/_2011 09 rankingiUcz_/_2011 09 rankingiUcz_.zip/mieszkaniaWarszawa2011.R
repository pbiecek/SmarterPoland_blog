library(lattice)
library(latticeExtra)
library(quantreg)
library(splines)
 
mieszkaniaKWW2011 <- 
     read.table("http://tofesi.mimuw.edu.pl/~cogito/smarterpoland/mieszkaniaKWW2011/mieszkaniaKWW2011.csv", 
         row.names=NULL, sep=";", header=TRUE, 
         colClasses=c("factor", "factor", "numeric", "numeric", "factor", "numeric", "numeric", "factor", "Date"))

mieszkaniaKWW2011Warszawa = mieszkaniaKWW2011[mieszkaniaKWW2011$miasto =="Warszawa", ]
mieszkaniaKWW2011Warszawa$dzielnica = factor(mieszkaniaKWW2011Warszawa$dzielnica)
mieszkaniaKWW2011Warszawa = mieszkaniaKWW2011Warszawa[mieszkaniaKWW2011Warszawa$powierzchnia<300, ]











by(mieszkaniaKWW2011Warszawa$data, mieszkaniaKWW2011Warszawa$dzielnica, function(x) c(mean(x<as.Date("13-09-2008","%d-%m-%Y")), sum(x<as.Date("13-09-2008","%d-%m-%Y"))))

dataStart = as.Date("13-09-2008","%d-%m-%Y")
dataStart = as.Date("13-09-2007","%d-%m-%Y")
mieszkaniaKWW2011Warszawa2 = mieszkaniaKWW2011Warszawa
mieszkaniaKWW2011Warszawa2$data[mieszkaniaKWW2011Warszawa2$data < dataStart]  =  dataStart
mieszkaniaKWW2011Warszawa2$dataF = factor(as.character(mieszkaniaKWW2011Warszawa2$data, "%Y-%m"))
table(mieszkaniaKWW2011Warszawa2$dataF, mieszkaniaKWW2011Warszawa2$dzielnica)

#
# usun male dzielnice
usun = names(which(table(mieszkaniaKWW2011Warszawa2$dzielnica)<2000))
mieszkaniaKWW2011Warszawa2 = mieszkaniaKWW2011Warszawa2[!(mieszkaniaKWW2011Warszawa2$dzielnica %in% usun),]
mieszkaniaKWW2011Warszawa2$dzielnica = factor(mieszkaniaKWW2011Warszawa2$dzielnica)

at = seq(1000,24000,1000)
at2 = c((1:10)*1000,12000,14000,16000,18000,20000,22000,24000)
mieszkaniaKWW2011Warszawa2$dzielnica2 = reorder(mieszkaniaKWW2011Warszawa2$dzielnica, mieszkaniaKWW2011Warszawa2$dzielnica, length)
mieszkaniaKWW2011Warszawa2$dzielnica2 = reorder(mieszkaniaKWW2011Warszawa2$dzielnica, mieszkaniaKWW2011Warszawa2$cenam2, median)

pozio = levels(mieszkaniaKWW2011Warszawa2$dzielnica2)
pozio2 = levels(mieszkaniaKWW2011Warszawa2$dataF)

pozio = paste(pozio," ",sapply(pozio, function(x) {
 tmp = mieszkaniaKWW2011Warszawa2[mieszkaniaKWW2011Warszawa2$dzielnica2==x,]
 skala = diff(range(as.numeric(tmp$dataF)))
 mod = rlm(tmp$cenam2 ~ I(as.numeric(tmp$dataF)/skala))$coeff
 l1 = round(1000*mod[2]/mod[1])

 mediany = sapply(pozio2, function(x) median(tmp[tmp$dataF == x,"cenam2"]))
 mod2 = rlm(mediany~I(seq_along(pozio2)/length(mediany)))$coeff
 l3 = round(1000*mod2[2]/mod2[1])
 
 l4 = round(1000*(mediany[length(mediany)]-mediany[1])/mediany[1])
 
 tmp2 = loess(tmp$cenam2 ~ I(as.numeric(tmp$dataF)/skala), span = 2/3, degree = 1, family = "symmetric" )$fitted
 l2 = round(1000*(tmp2[1] - tmp2[length(tmp2)])/tmp2[1])
 paste(l1/10, "% / ", l3/10, "% / ", l2/10, "% / ", l4/10, "% / ", sep="")
}), sep="")
levels(mieszkaniaKWW2011Warszawa2$dzielnica2) <- pozio 



bwplot(cenam2~dataF|dzielnica2, data=mieszkaniaKWW2011Warszawa2, scales=list(y=list(log=T, at=at2),x=list(rot=90)), ylim=c(4000, 25000), panel = function(...) {
  panel.abline(h=log(at,10), col="grey")
  tt = trellis.par.get("plot.symbol")
  tt$pch=19
  tt$cex=1/2
  trellis.par.set("plot.symbol",tt)
  panel.bwplot(...)
  args = list(...)
  mod = rlm(args$y~as.numeric(args$x))
  panel.abline(mod, col="green", lwd=3)

  mediany = sapply(pozio2, function(x) median(args$y[args$x == x]))
  mod2 = rlm(mediany~seq_along(pozio2))
  panel.abline(mod2, col="yellow", lwd=3)
  
  llines(c(1,length(mediany)), mediany[c(1,length(mediany))], col="orange",lwd=3)
  
  panel.loess(..., col="red", lwd=3)
})


library(MASS)
res = by(mieszkaniaKWW2011Warszawa2, mieszkaniaKWW2011Warszawa2$dzielnica, function(x) {
  mod = rlm(cenam2~powierzchnia+data, x)  
  mod = rlm(cenam2~data, x)  
  predict(mod, data.frame(powierzchnia=c(70,70), data=as.Date(c("13-09-2007", "13-09-2011"), "%d-%m-%Y")))
})


matt = matrix(unlist(res), ncol=2, byrow=T)
rownames(matt) = names(res)
plot(matt)
abline(0,1)
plot(matt[,2], 100*matt[,2]/matt[,1] - 100, pch=19)
text(matt[,2], 100*matt[,2]/matt[,1] - 100, rownames(matt), adj=c(0,0))



poziomy = levels(mieszkaniaKWW2011Warszawa2$dataF)
table(mieszkaniaKWW2011Warszawa2$dataF, mieszkaniaKWW2011Warszawa2$dzielnica)



innn = mieszkaniaKWW2011Warszawa2[mieszkaniaKWW2011Warszawa2$dzielnica == "Srodmiescie",]
xyplot(cenam2~data, innn, type=c("p","g","r","smooth"), pch=".", lwd=3, ylim=c(6000,20000))

res = by(mieszkaniaKWW2011Warszawa2, mieszkaniaKWW2011Warszawa2$dzielnica, function(innn) {
  mediany = sapply(poziomy, function(x) median(innn[innn$dataF == x,"cenam2"])    )
  (mod = rlm(cenam2~data, innn)  )
  dataN = as.Date(paste(poziomy,"-01",sep=""), "%Y-%m-%d")
  (mod = rlm(mediany~dataN)  )
  pred = predict(mod, data.frame(powierzchnia=c(70,70), dataN=as.Date(c("13-09-2007", "13-09-2011"), "%d-%m-%Y")))
  c(pred[2], 100*(pred[1] - pred[2])/pred[1])
})
matt = matrix(unlist(res), ncol=2, byrow=T)
rownames(matt) = names(res)
plot(matt,xlab="utrata na wartosci",ylab="% zmiana")
text(matt[,1], matt[,2], rownames(matt), adj=c(0,0))


resDM = by(mieszkaniaKWW2011Warszawa2, mieszkaniaKWW2011Warszawa2$dzielnica, function(innn) {
  mediany = sapply(poziomy, function(x) median(innn[innn$dataF == x,"cenam2"])    )
  })
mattDM = matrix(unlist(resDM), ncol=37, byrow=T)
rownames(mattDM) = names(res)

mattDM2 = t(apply(mattDM,1,function(x) diff(x)/x[-length(x)]))*100
matplot(t(mattDM[,-37]), t(mattDM2), type="l")
tmp =  apply(mattDM, 1, function(x) {
          tmp = rlm(I(x[1:12]-x[1])~I((1:12)/12)-1)$coeff
          a1 = c(mean(x[1:12],na.rm=T), tmp[1]/x[1]*100)
          tmp = rlm(I(x[13:24]-x[13])~I((1:12)/12)-1)$coeff
          a2 = c(mean(x[13:24],na.rm=T), tmp[1]/x[13]*100)
          tmp = rlm(I(x[25:36]-x[25])~I((1:12)/12)-1)$coeff
          a3 = c(mean(x[25:36],na.rm=T), tmp[1]/x[25]*100)
          c(a1,a2,a3)
          })
matplot(tmp[c(1,3,5),], tmp[c(2,4,6),], type="l", pch=19)
matpoints(tmp[1,], tmp[2,], col="red", pch=19)
abline(h=0)
text(tmp[1,], tmp[2,], colnames(tmp), adj=c(0,0))





# rys 1
png("mieszkaniaKWW2011Warszawa1.png", 800, 600)
xyplot(cenam2~powierzchnia, groups=dzielnica, data=mieszkaniaKWW2011Warszawa, type=c("smooth"), ylim=c(4500,9500), xlim=c(18,105), auto.key=list(columns=6, lwd=5, pch=19), lwd=4, pch=19, cex=0.2, xlab="powierzchnia [m^2]", ylab="srednia cena za m^2 [PLN]", main="Warszawa")
dev.off()

# rys 2
png("mieszkaniaKWW2011Warszawa2.png", 800, 600)
xyplot(I(cenam2 - 15*powierzchnia + 15*50)~data, groups=dzielnica, data=mieszkaniaKWW2011Warszawa, type=c("smooth"), ylim=c(6000,13500), auto.key=list(columns=6, lwd=5, pch=19), lwd=4, pch=19, cex=0.2, xlab="data oferty", ylab="srednia cena za m^2 [PLN]", main="Warszawa, mieszkanie 50m2")
dev.off()

mieszkaniaKWW2011Warszawa$data


# rys 3
png("mieszkaniaKWW2011Warszawa3.png", 800, 600)
 tab = table(factor(format(mieszkaniaKWW2011Warszawa$data, "%Y %m")), mieszkaniaKWW2011Warszawa$dzielnica)
 tab2 = as.data.frame(tab)
 tab2$Var1 = as.Date(paste(tab2$Var1,"15"), "%Y %m %d")
  xyplot(Freq~Var1, groups=Var2, data=tab2, type="smooth", scales = list(y = list(log = TRUE)), xlab="data oferty", ylab="liczba ofert", lwd=4, auto.key=list(columns=6, lwd=5, pch=19), main="Warszawa")
dev.off()

















xyplot(log(cenam2)~log(powierzchnia)|dzielnica, data=mieszkaniaKWW2011, pch=19, cex=0.3, auto.key=list(columns = 4),  type=c("p","smooth"), subset= miasto=="Warszawa")

xyplot(cenam2~data, groups = miasto, data=mieszkaniaKWW2011, pch=19, cex=0.3, auto.key=list(columns = 4),  type=c("smooth"), ylim=c(5000,10000)) + 
  layer(panel.quantile(mieszkaniaKWW2011$data, mieszkaniaKWW2011$cenam2, tau = c(.5, .9, .1), superpose = TRUE))


xyplot(cenam2~data, groups = miasto, data=mieszkaniaKWW2011, pch=19, cex=0.3, type=c("smooth"), ylim=c(5000,10000), panel = function(...) {
    panel.xyplot(..., lwd=3)
    tmp = list(...)
    panel.quantile(tmp$x, tmp$y, tau = c(.5, .9, .1))
  })

mieszkaniaKWW2011Warszawa = mieszkaniaKWW2011[mieszkaniaKWW2011$miasto =="Warszawa", ]
mieszkaniaKWW2011Warszawa$dzielnica = factor(mieszkaniaKWW2011Warszawa$dzielnica)
mieszkaniaKWW2011Warszawa = mieszkaniaKWW2011Warszawa[mieszkaniaKWW2011Warszawa$powierzchnia<100, ]

xyplot(cenam2~data, groups=dzielnica, data=mieszkaniaKWW2011Warszawa, pch=19, cex=0.3, auto.key=list(columns = 4),  type=c("smooth"), ylim=c(4000,10000), lwd=3)


summary(lm(cenam2~dzielnica+powierzchnia+data, mieszkaniaKWW2011Warszawa))


# rys 1
plot1 = xyplot(cenam2~powierzchnia, groups=dzielnica, data=mieszkaniaKWW2011Warszawa, type=c("smooth"), ylim=c(4500,9500), xlim=c(18,105), auto.key=list(columns=4, lwd=5, pch=19), lwd=4, pch=19, cex=0.2, xlab="powierzchnia [m^2]", ylab="cena za m^2 [PLN]", main="Warszawa")

# rys 2
plot2 = xyplot(I(cenam2 - 15*powierzchnia + 15*50)~data, groups=dzielnica, data=mieszkaniaKWW2011Warszawa, type=c("smooth"), ylim=c(4500,9500), auto.key=list(columns=4, lwd=5, pch=19), lwd=4, pch=19, cex=0.2, xlab="data oferty", ylab="cena za m^2 [PLN]", main="Warszawa, mieszkanie 50m2")

# rys 3
 tab = table(factor(format(mieszkaniaKWW2011Warszawa$data, "%Y %m")), mieszkaniaKWW2011Warszawa$dzielnica)
 tab2 = as.data.frame(tab)
 tab2$Var1 = as.Date(paste(tab2$Var1,"15"), "%Y %m %d")
plot3 =  xyplot(Freq~Var1, groups=Var2, data=tab2, type="smooth", scales = list(y = list(log = TRUE)), xlab="data oferty", ylab="liczba ofert", lwd=4, auto.key=list(columns=4, lwd=5, pch=19), main="Warszawa")


plot(plot1, split=c(1,1,3,1))
plot(plot2, split=c(2,1,3,1), newpage=F)
plot(plot3, split=c(3,1,3,1), newpage=F)

                   
                   
                   
                   