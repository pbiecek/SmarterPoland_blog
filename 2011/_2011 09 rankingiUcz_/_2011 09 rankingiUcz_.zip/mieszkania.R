library(lattice)
library(latticeExtra)
library(quantreg)
library(splines)
 
mieszkaniaKWW2011 <- 
     read.table("http://tofesi.mimuw.edu.pl/~cogito/smarterpoland/mieszkaniaKWW2011/mieszkaniaKWW2011.csv", 
         row.names=NULL, sep=";", header=TRUE, 
         colClasses=c("factor", "factor", "numeric", "numeric", "factor", "numeric", "numeric", "factor", "Date"))

mieszkaniaKWW2011Wroclaw = mieszkaniaKWW2011[mieszkaniaKWW2011$miasto =="Wroclaw", ]
mieszkaniaKWW2011Wroclaw$dzielnica = factor(mieszkaniaKWW2011Wroclaw$dzielnica)
mieszkaniaKWW2011Wroclaw = mieszkaniaKWW2011Wroclaw[mieszkaniaKWW2011Wroclaw$powierzchnia<100, ]

# rys 1
png("mieszkaniaKWW2011Wroclaw1.png", 800, 600)
xyplot(cenam2~powierzchnia, groups=dzielnica, data=mieszkaniaKWW2011Wroclaw, type=c("smooth"), ylim=c(4500,9500), xlim=c(18,105), auto.key=list(columns=6, lwd=5, pch=19), lwd=4, pch=19, cex=0.2, xlab="powierzchnia [m^2]", ylab="srednia cena za m^2 [PLN]", main="Wroclaw")
dev.off()

# rys 2
png("mieszkaniaKWW2011Wroclaw2.png", 800, 600)
xyplot(I(cenam2 - 15*powierzchnia + 15*50)~data, groups=dzielnica, data=mieszkaniaKWW2011Wroclaw, type=c("smooth"), ylim=c(4500,9500), auto.key=list(columns=6, lwd=5, pch=19), lwd=4, pch=19, cex=0.2, xlab="data oferty", ylab="srednia cena za m^2 [PLN]", main="Wroclaw, mieszkanie 50m2")
dev.off()

# rys 3
png("mieszkaniaKWW2011Wroclaw3.png", 800, 600)
 tab = table(factor(format(mieszkaniaKWW2011Wroclaw$data, "%Y %m")), mieszkaniaKWW2011Wroclaw$dzielnica)
 tab2 = as.data.frame(tab)
 tab2$Var1 = as.Date(paste(tab2$Var1,"15"), "%Y %m %d")
  xyplot(Freq~Var1, groups=Var2, data=tab2, type="smooth", scales = list(y = list(log = TRUE)), xlab="data oferty", ylab="liczba ofert", lwd=4, auto.key=list(columns=6, lwd=5, pch=19), main="Wroclaw")
dev.off()

















xyplot(log(cenam2)~log(powierzchnia)|dzielnica, data=mieszkaniaKWW2011, pch=19, cex=0.3, auto.key=list(columns = 4),  type=c("p","smooth"), subset= miasto=="Warszawa")

xyplot(cenam2~data, groups = miasto, data=mieszkaniaKWW2011, pch=19, cex=0.3, auto.key=list(columns = 4),  type=c("smooth"), ylim=c(5000,10000)) + 
  layer(panel.quantile(mieszkaniaKWW2011$data, mieszkaniaKWW2011$cenam2, tau = c(.5, .9, .1), superpose = TRUE))


xyplot(cenam2~data, groups = miasto, data=mieszkaniaKWW2011, pch=19, cex=0.3, type=c("smooth"), ylim=c(5000,10000), panel = function(...) {
    panel.xyplot(..., lwd=3)
    tmp = list(...)
    panel.quantile(tmp$x, tmp$y, tau = c(.5, .9, .1))
  })

mieszkaniaKWW2011Wroclaw = mieszkaniaKWW2011[mieszkaniaKWW2011$miasto =="Wroclaw", ]
mieszkaniaKWW2011Wroclaw$dzielnica = factor(mieszkaniaKWW2011Wroclaw$dzielnica)
mieszkaniaKWW2011Wroclaw = mieszkaniaKWW2011Wroclaw[mieszkaniaKWW2011Wroclaw$powierzchnia<100, ]

xyplot(cenam2~data, groups=dzielnica, data=mieszkaniaKWW2011Wroclaw, pch=19, cex=0.3, auto.key=list(columns = 4),  type=c("smooth"), ylim=c(4000,10000), lwd=3)


summary(lm(cenam2~dzielnica+powierzchnia+data, mieszkaniaKWW2011Wroclaw))


# rys 1
plot1 = xyplot(cenam2~powierzchnia, groups=dzielnica, data=mieszkaniaKWW2011Wroclaw, type=c("smooth"), ylim=c(4500,9500), xlim=c(18,105), auto.key=list(columns=4, lwd=5, pch=19), lwd=4, pch=19, cex=0.2, xlab="powierzchnia [m^2]", ylab="cena za m^2 [PLN]", main="Wroclaw")

# rys 2
plot2 = xyplot(I(cenam2 - 15*powierzchnia + 15*50)~data, groups=dzielnica, data=mieszkaniaKWW2011Wroclaw, type=c("smooth"), ylim=c(4500,9500), auto.key=list(columns=4, lwd=5, pch=19), lwd=4, pch=19, cex=0.2, xlab="data oferty", ylab="cena za m^2 [PLN]", main="Wroclaw, mieszkanie 50m2")

# rys 3
 tab = table(factor(format(mieszkaniaKWW2011Wroclaw$data, "%Y %m")), mieszkaniaKWW2011Wroclaw$dzielnica)
 tab2 = as.data.frame(tab)
 tab2$Var1 = as.Date(paste(tab2$Var1,"15"), "%Y %m %d")
plot3 =  xyplot(Freq~Var1, groups=Var2, data=tab2, type="smooth", scales = list(y = list(log = TRUE)), xlab="data oferty", ylab="liczba ofert", lwd=4, auto.key=list(columns=4, lwd=5, pch=19), main="Wroclaw")


plot(plot1, split=c(1,1,3,1))
plot(plot2, split=c(2,1,3,1), newpage=F)
plot(plot3, split=c(3,1,3,1), newpage=F)

                   