#
# Oferty sprzedazy mieszkan z lat 2006-2011 z Wroclawia, Krakowa i Warszawy
# Wczytanie danych o mieszkaniach bezposrednio z internetu
#

mieszkaniaKWW2011 <- 
     read.table("http://tofesi.mimuw.edu.pl/~cogito/smarterpoland/mieszkaniaKWW2011/mieszkaniaKWW2011.csv", 
         row.names=NULL, sep=";", header=TRUE, 
         colClasses=c("factor", "factor", "numeric", "numeric", "factor", "numeric", "numeric", "factor", "Date"))

# Podsumowanie kolumn
#
# summary(mieszkaniaKWW2011)
#      miasto                 ulica            pokoi         powierzchnia        pietro     
# Krakow  : 39457                : 24046   Min.   : 1.000   Min.   : 10.00   1      :33674  
# Warszawa:127776   sarmacka     :  1195   1st Qu.: 2.000   1st Qu.: 45.00   2      :31933  
# Wroclaw : 21651   odkryta      :   953   Median : 2.000   Median : 57.00   3      :30067  
#                   pulawska     :   946   Mean   : 2.545   Mean   : 63.09   parter :26848  
#                   skarbka z gor:   848   3rd Qu.: 3.000   3rd Qu.: 74.00   4      :21889  
#                   gorczewska   :   835   Max.   :60.000   Max.   :800.00   5      :11023  
#
#      cena              cenam2               dzielnica           data           
# Min.   :   30000   Min.   :  608   Mokotow       : 19862   Min.   :2006-10-23  
# 1st Qu.:  338000   1st Qu.: 6902   Srodmiescie   : 18150   1st Qu.:2010-12-11  
# Median :  440000   Median : 8033   Praga-Poludnie: 13837   Median :2011-05-17  
# Mean   :  549459   Mean   : 8519   Ursynow       : 11023   Mean   :2011-02-18  
# 3rd Qu.:  621297   3rd Qu.: 9490   Wola          :  9131   3rd Qu.:2011-08-02  
# Max.   :15000000   Max.   :95315   Krzyki        :  8180   Max.   :2011-09-14  
#
# dane z serwisu ofery.net opisuja prawie 19 tys ofert
# dla kazdej oferty podane sa nastepujace dane
# miasto      - [faktor] miasto w ktorym jest oferowane mieszkanie
# ulica       - [faktor] ulica na ktorej jest oferowane mieszkanie
# pokoi       - liczba pokoi
# powierzchnia- powierzchnia mieszkania
# pietro      - [faktor] pietro na ktorym jest mieszkanie
# cena        - ofertowa cena mieszkania 
# cenam2      - przeliczona cena za metr kwadratowy
# dzielnica   - [faktor] dzielnica w ktorej znajduje sie mieszkanie (administracyjna)
# data        - [data] data zgloszenia oferty 
#

