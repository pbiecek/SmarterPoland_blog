library(ellipse)

dat = rankingUczelni2011[,-(1:8)]
rownames(dat) = paste(rankingUczelni2011[,2], " ", rankingUczelni2011[,3], " (", rankingUczelni2011[,4], ")", sep="")

colors <- rev(c("#A50F15","#DE2D26","#FB6A4A","#FCAE91","#FEE5D9","white",
  "#EFF3FF","#BDD7E7","#6BAED6","#3182BD","#08519C"))

corrS <- cor(dat, method="spearman")


noweKategorie = rep("inne",nrow(dat))
noweKategorie[grep(as.character(rankingUczelni2011[,2]), pattern="Akademia")] = "Akademie"
noweKategorie[grep(as.character(rankingUczelni2011[,2]), pattern="Uniwersytet")] = "Inne uniwersytety"
noweKategorie[as.character(rankingUczelni2011[,2])=="Uniwersytet"] = "Uniwersytet"
noweKategorie[as.character(rankingUczelni2011[,2])=="Politechnika"] = "Politechnika"
noweKategorie[as.character(rankingUczelni2011[,2])=="Uniwersytet Medyczny"] = "Uniwersytet Medyczny"
noweKategorie = factor(noweKategorie)

#pdf("b3.pdf",15,15)
png("b3.png",1000,1000)
plotcorr(corrS, col=colors[5*corrS +6])
abline(h = c(  7.5, 12.5, 21.5, 25.5, 28.5))
abline(v = 33-c(  7.5, 12.5, 21.5, 25.5, 28.5))

mtext(rev(nazwy), side=4, at=c(0, 7.5, 12.5, 21.5, 25.5, 28.5), adj=0, line=rep(-1:-2,3))
mtext(rev(nazwy), side=1, at=33-c(0, 7.5, 12.5, 21.5, 25.5, 28.5), adj=1, line=rep(1:2,3))
dev.off()


#pdf("b5.pdf",20,15)
png("b5.png",1200,800)
plot(hclust(dist(dat),method="average"),ylab="Podobienstwo profili uczelni", sub="", xlab="",main="")
dev.off()
pdf("b6.pdf",10,10)
#png("b6.png",800,800)
plot(hclust(dist(t(dat)),method="complete"),ylab="Podobienstwo wspolczynnikow", sub="", xlab="",main="")
dev.off()

library(MASS)
odl = dist(t(log(dat+1)))
res = isoMDS(odl,k=2)

#pdf("_MDS.pdf",13,10)
png("_MDS.png",1000,800)

plot(res$points, col="white",bty="n", xlab="", ylab="")
par(xpd=NA)
for (i in 1:6)
  text(res$points[indeksy[[i]]-8,1], res$points[indeksy[[i]]-8,2], colnames(dat[indeksy[[i]]-8]), srt=25, col=i)
legend("top", col=1:6, nazwy, lwd=3, horiz=T, bty="n", inset=-0.1)
par(xpd=T)

dev.off()




noweWsp = matrix(0, nrow(dat), 6)
rownames(noweWsp) = rownames(dat)
colnames(noweWsp) = nazwy
for (i in 1:6)
  noweWsp[,i] = rowSums(dat[,indeksy[[i]]-8])



rownames(dat) = paste(rankingUczelni2011[,2], " ", rankingUczelni2011[,3], sep="")
rownames(noweWsp) = rownames(dat)

library(RColorBrewer)
kol1 = brewer.pal(12, "Paired")[seq(1,12,2)]
kol2 = brewer.pal(12, "Paired")[seq(2,12,2)]
tmp = c(0,10,50,100,200,300,400,500)


for (w1 in 1:6)
  for (w2 in (1:6)[-w1]) {
png(paste(nazwy[w1],".",nazwy[w2],".png",sep=""),700,600)

par(mar=c(4,4,7,7))
wspX = sqrt(noweWsp[,w1])
wspY = sqrt(noweWsp[,w2])
plot(wspX, wspY, xlab="", ylab="", bty="l", pch=19, col=kol1[noweKategorie], cex=1.5, xaxt="n", yaxt="n", xlim=sqrt(c(10,500)), ylim=sqrt(c(10,500)), xaxs="i", yaxs="i")
title(main=paste(nazwy[w1], "vs", nazwy[w2]), line=5.5)

mtext(nazwy[w1], side=1, at=sqrt(c(10,580)), adj=c(0,1), line=2.2)
mtext(nazwy[w2], side=2, at=sqrt(c(10,580)), adj=c(0,1), line=2.7)

axis(1, at=sqrt(tmp), labels=tmp, las=1)
axis(2, at=sqrt(tmp), labels=tmp, las=1)
indy = (wspX + wspY) > quantile((wspX + wspY),0.9)
par(xpd=NA)
points(wspX[indy], wspY[indy], pch=19, col=kol2[noweKategorie[indy]], cex=1.5)

tmp2 = wspY[indy]
podniesc = names(which(diff(sort(tmp2))<0.4))
wspY[podniesc] = wspY[podniesc] + 0.4

text(wspX[indy], wspY[indy], rownames(dat)[indy], adj=c(0,-0.5), cex=0.85)
par(xpd=T)
legend("top", inset=-0.15, levels(noweKategorie), fill=kol1, border=kol2, bty="n", ncol=3)

dev.off()
}
