#
# Ranking uczelni wyzszych opracowany przez Rzeczpospolita w roku 2011
# Wczytanie danych o mieszkaniach bezposrednio z internetu
#

rankingUczelni2011 <-
     read.table("http://tofesi.mimuw.edu.pl/~cogito/smarterpoland/rankingUczelni2011/RankingUczelni2011.csv",
         row.names=NULL, sep=";", header=TRUE, skip=1, na.strings="-")
nazwy    <- c("prestiz", "innowacyjnosc", "potencjal naukowy", "efektywnosc naukowa", "warunki studiowania", "umiedzynarodowienie")
indeksy  <- list(c(9:12), c(13:15), c(16:19), c(20:28), c(29:33), c(34:40))

# Podsumowanie kolumn
#
# summary(rankingUczelni2011)
#      Miasto                           Typ.Uczelni       Reszta.Nazwy  ranking.2011    ranking.2010  ranking.2009    ranking.2008    suma.punktow
# Warszawa:18   Uniwersytet                   :17   w Krakowie  : 4    Min.   : 1.00   Min.   : 1    Min.   : 1.00   Min.   : 1.00   Min.   : 14.63
# Krakow  :10   Politechnika                  :15   w Poznaniu  : 4    1st Qu.:23.25   1st Qu.:23    1st Qu.:23.00   1st Qu.:23.00   1st Qu.: 25.47
# Wroclaw : 7   Szkola Wyzsza                 : 8   w Warszawie : 4    Median :45.50   Median :45    Median :45.00   Median :46.00   Median : 32.26
# Lodz    : 6   Uniwersytet Medyczny          : 8   we Wroclawiu: 3    Mean   :45.50   Mean   :45    Mean   :45.01   Mean   :45.65   Mean   : 37.38
# Poznan  : 6   Akademia Wychowania Fizycznego: 5   Gdanski     : 2    3rd Qu.:67.75   3rd Qu.:67    3rd Qu.:67.00   3rd Qu.:68.00   3rd Qu.: 47.30
# Katowice: 5   Akademia                      : 4   Krakowska   : 2    Max.   :90.00   Max.   :89    Max.   :90.00   Max.   :91.00   Max.   :100.00
# (Other) :38   (Other)                       :33   (Other)     :71                    NA's   : 1    NA's   : 1.00   NA's   : 1.00
# preferencje.pracodawcow ocena.kadry.akademickiej uznanie.miedzynarodowe wybor.olimpijczykow patenty.i.inne     srodki.z.UE      zaplecze.innowacyjne
# Min.   :  0.000         Min.   :  0.000          Min.   :  0.000        Min.   :  0.000     Min.   :  0.000   Min.   :  0.000   Min.   :  0.00
# 1st Qu.:  1.245         1st Qu.:  0.940          1st Qu.:  0.000        1st Qu.:  0.000     1st Qu.:  0.000   1st Qu.:  5.303   1st Qu.: 12.59
# Median :  5.165         Median :  2.830          Median :  0.000        Median :  1.200     Median :  1.520   Median : 17.550   Median : 28.44
# Mean   : 13.326         Mean   :  9.597          Mean   :  4.661        Mean   :  5.745     Mean   :  9.244   Mean   : 26.591   Mean   : 31.63
# 3rd Qu.: 14.047         3rd Qu.: 10.818          3rd Qu.:  0.000        3rd Qu.:  7.607     3rd Qu.:  9.717   3rd Qu.: 38.862   3rd Qu.: 52.08
# Max.   :100.000         Max.   :100.000          Max.   :100.000        Max.   :100.000     Max.   :100.000   Max.   :100.000   Max.   :100.00
#
# ocena.parametryczna uprawnienia.do.nawadania.stopni.naukowych nasycenie.kadry.profesorami  akredytacje     rozwoj.kadry.wlasnej nadane.stopnie.naukowe
# Min.   :  0.00      Min.   :  0.00                            Min.   : 23.34              Min.   :  0.00   Min.   :  0.00       Min.   :  0.00
# 1st Qu.: 64.25      1st Qu.:  4.09                            1st Qu.: 39.09              1st Qu.:  0.00   1st Qu.: 24.91       1st Qu.: 12.55
# Median : 74.14      Median : 14.91                            Median : 45.14              Median :  7.14   Median : 33.80       Median : 27.86
# Mean   : 72.80      Mean   : 22.41                            Mean   : 48.50              Mean   : 13.81   Mean   : 34.73       Mean   : 27.31
# 3rd Qu.: 85.64      3rd Qu.: 25.00                            3rd Qu.: 52.65              3rd Qu.: 17.86   3rd Qu.: 43.00       3rd Qu.: 37.84
# Max.   :100.00      Max.   :100.00                            Max.   :100.00              Max.   :100.00   Max.   :100.00       Max.   :100.00
#
# pozyskiwanie.srodkow.zewnetrznych.na.badania   publikacje       cytowania         h.index       udzial.uczelni.w.PR studia.doktoranckie
# Min.   :  0.000                              Min.   :  0.00   Min.   :  0.00   Min.   :  0.00   Min.   :  0.000     Min.   :  0.000
# 1st Qu.:  2.928                              1st Qu.:  7.60   1st Qu.: 11.16   1st Qu.: 10.64   1st Qu.:  0.000     1st Qu.:  5.652
# Median :  6.860                              Median : 29.41   Median : 16.90   Median : 21.28   Median :  1.750     Median : 14.540
# Mean   : 10.388                              Mean   : 33.86   Mean   : 18.44   Mean   : 28.42   Mean   :  7.271     Mean   : 18.667
# 3rd Qu.: 13.248                              3rd Qu.: 51.19   3rd Qu.: 25.58   3rd Qu.: 44.68   3rd Qu.:  7.020     3rd Qu.: 23.490
# Max.   :100.000                              Max.   :100.00   Max.   :100.00   Max.   :100.00   Max.   :100.000     Max.   :100.000
#
# dostepnosc.kadr.dla.studentow zbiory.elektroniczne zbiory.drukowane korzystanie.z.biblioteki dostepnosc.dla.studentow.zamiejscowych osiagniecia.sportowe
# Min.   : 10.36                Min.   :  0.470      Min.   :  4.62   Min.   :  3.42           Min.   :  0.00                         Min.   :  0.000
# 1st Qu.: 26.21                1st Qu.:  9.765      1st Qu.: 13.74   1st Qu.: 55.30           1st Qu.: 11.40                         1st Qu.:  7.843
# Median : 32.51                Median : 18.270      Median : 19.35   Median : 70.38           Median : 20.97                         Median : 31.525
# Mean   : 36.60                Mean   : 22.132      Mean   : 24.40   Mean   : 65.33           Mean   : 21.95                         Mean   : 40.578
# 3rd Qu.: 39.97                3rd Qu.: 30.195      3rd Qu.: 28.16   3rd Qu.: 74.81           3rd Qu.: 31.40                         3rd Qu.: 72.695
# Max.   :100.00                Max.   :100.000      Max.   :100.00   Max.   :100.00           Max.   :100.00                         Max.   :100.000
#
# studia.w.j.obcym studiujacy.w.j.obcym wymiana.studencka.wyjazdy wymiana.studencka.przyjazdy wielokulturowosc  nauczyciele.z.zagranicy wyklady.w.j.obcych
# Min.   :  0.00   Min.   :  0.000      Min.   :  0.00            Min.   :  0.000             Min.   :  0.000   Min.   :  0.000         Min.   :  0.000
# 1st Qu.:  0.00   1st Qu.:  0.000      1st Qu.:  9.55            1st Qu.:  2.678             1st Qu.:  1.305   1st Qu.:  7.088         1st Qu.:  1.080
# Median :  3.85   Median :  1.715      Median : 18.66            Median :  6.305             Median :  3.830   Median : 18.530         Median :  7.675
# Mean   : 15.47   Mean   : 14.756      Mean   : 24.09            Mean   : 11.317             Mean   : 12.279   Mean   : 23.278         Mean   : 14.525
# 3rd Qu.: 19.23   3rd Qu.: 22.425      3rd Qu.: 33.16            3rd Qu.: 13.312             3rd Qu.:  8.602   3rd Qu.: 35.508         3rd Qu.: 16.440
# Max.   :100.00   Max.   :100.000      Max.   :100.00            Max.   :100.000             Max.   :100.000   Max.   :100.000         Max.   :100.000
#
##
# dane pochodza z serwisu rzeczpospolitej, bezposredni link do pdf'a z danymi
# http://grafik.rp.pl/grafika2/683688
#
#Miasto w ktorym zlokalizowany jest rektorat uczelni
#Dwie kolumny opisujace nazwe uczelni
#Cztery kolumny okreslajace miejsce w rankingach w kolejnych latach
#Suma punktow i punkty w 6 obszarach
#[Prestiz]
#A � preferencje pracodawc�w,
#B � ocena przez kadra akademicka,
#C � uznania miedzynarodowe,
#D � wyb�r olimpijczyk�w,
#[Innowacyjnosc]
#E � patenty, prawa ochronne i licencje,
#F � pozyskane srodki z UE,
#G � zaplecze innowacyjne uczelni,
#[Potencjal Naukowy]
#H � ocena paramertryczna,
#I � uprawnienia do nadawania stopni naukowych,
#J � nasycenie kadry osobami o najwyzszych kwalifikacjach,
#K � akredytacje,
#[Efektywnosc Naukowa]
#L � rozw�j kadry wlasnej,
#M � nadane stopnie naukowe,
#N � efektywnosc pozyskiwania zewnetrznych srodk�w finansowych na badania,
#O � publikacje,
#P � cytowania,
#R � h-index,
#S � udzial uczelni w 7. Programie Ramowym UE,
#T � studia doktoranckie,
#U � dostepnosc dla student�w kadr wysoko kwalifikowanych,
#[Warunki Studiowania]
#W � zbiory elektroniczne,
#Z1 � zbiory drukowane,
#Z2 � warunki korzystania z biblioteki,
#Z3 � dostepnosc uczelni dla student�w zamiejscowych,
#Z4 � osiagniecia sportowe,
#[Umiedzynarodowienie]
#Z5 � programy studi�w prowadzone w j.obcych,
#Z6 � studiujacy w j. obcych,
#Z7 � wymiana studencka (wyjazdy),
#Z8 � wymiana studencka (przyjazdy),
#Z9 � wielokulturowosc srodowiska studenckiego (obcokrajowcy),
#Z10 � nauczyciele akademiccy z zagranicy,
#Z11 � wyklady w j. obcych
