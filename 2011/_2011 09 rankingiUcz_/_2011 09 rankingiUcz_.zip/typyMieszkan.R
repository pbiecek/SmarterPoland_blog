# typ 1 
# kawalerka, 1 pokoj 
# 20-35 m2

subset(mieszkaniaKWW2011, pokoi == 1 & powierzchnia >= 20 & powierzchnia <= 35)
          
          
# typ 2
# mieszkanie, 2 pokoje
# 40-55 m2

subset(mieszkaniaKWW2011, pokoi == 2 & powierzchnia >= 40 & powierzchnia <= 55)


# typ 3
# mieskzanie 3-4 pokoje
# 60-80 m2




library(lattice)
library(splines)

tmp2 = subset(mieszkaniaKWW2011Wroclaw, pokoi >= 3 & pokoi <= 4 & powierzchnia >= 60 & powierzchnia <= 80)

xyplot(cenam2~data, tmp2, type="smooth", ylim=c(6000,10000))
summary(model <- lm(cenam2~ns(powierzchnia,8), tmp2))
tt = predict(model, data.frame(powierzchnia=20:100))


xyplot(cenam2~powierzchnia, tmp2, type="smooth", ylim=c(6000,10000), xlim=c(50,90))
plot(xyplot(tt~I(20:100), ylim=c(6000,10000), xlim=c(50,90), type="l", col="red"),newpage=F)

colnames(tmp2)[9] = "dat"

attach(tmp2)
xyplot(cenam2~dat, tmp2, type="smooth", ylim=c(4000,9000)) +
    layer(panel.quantile(cenam2 ~ dat, tau = c(0.1, 0.9)))
detach(tmp2)
  

plot(xyplot(tt~I(20:100), ylim=c(6000,10000), xlim=c(50,90), type="l", col="red"),newpage=F)


df1 = data.frame(dat=sort(unique(tmp2$dat)))
df2 = predict(rq(cenam2~dat, data=tmp2, tau=c(0.1,0.5,0.9)), df1)
df3 = data.frame(df1, df2)
colnames(df3) = c("dat", "q1", "q5", "q9")

xyplot(cenam2~dat, tmp2, type=c("p","smooth"), cex=0.2, ylim=c(4000,10000)) 
plot(xyplot(q1~dat, df3, type="l", ylim=c(4000,10000), col='red'),newpage=F)
plot(xyplot(q5~dat, df3, type="l", ylim=c(4000,10000), col='red'),newpage=F)
plot(xyplot(q9~dat, df3, type="l", ylim=c(4000,10000), col='red'),newpage=F)


attach(mieszkaniaKWW2011Wroclaw)
rodzaj = numeric(nrow(mieszkaniaKWW2011Wroclaw))
rodzaj[pokoi == 1 & powierzchnia >= 20 & powierzchnia <= 35] = 1
rodzaj[pokoi == 2 & powierzchnia >= 40 & powierzchnia <= 55] = 2
rodzaj[pokoi >= 3 & pokoi <= 4 & powierzchnia >= 60 & powierzchnia <= 80] = 3
detach(mieszkaniaKWW2011Wroclaw)

rodzaj[rodzaj==0] = NA
naz = c("kawalerka", "2 pokoje", "3-4 pokoje")
mieszkaniaKWW2011Wroclaw$rodzaj = factor(rodzaj, labels=naz)


png("mieszkaniaKWW2011Wroclaw4.png", 800, 600)
xyplot(cenam2~data|dzielnica, groups=rodzaj, mieszkaniaKWW2011Wroclaw, type=c("p","smooth"), cex=0.2, lwd=3, ylim=c(4000,10000), auto.key=list(columns=3, lwd=6), ylab="cena m^2", xlab="data", main="Wroclaw",
   panel = function(...) {
    params = list(...)
    kolory = trellis.par.get("superpose.symbol")$col
    for (id in 1:3) {
        df2 = subset(data.frame(params$x, params$y), as.character(params$groups[params$subscripts]) == naz[id])
        df2 = df2[order(df2[,1]),]
        panel.xyplot(df2[,1], df2[,2], type="smooth", lwd=1, col=kolory[id], family="gaussian", degree=1, span=0.5, lty=3)
        # przygotowanie danych
        df3 = data.frame(params.x=sort(unique(df2[,1])))
        df4 = rq(params.y~ns(params.x,4), data=df2, tau=c(0.25,0.5,0.75))$fitted.value
        df5 = data.frame(df2, df4)
        colnames(df5) = c("dat", "q1", "q5", "q9")
        # rysowanie przedzialow
        panel.xyplot(df5$dat, df5$q5, type="l", col=kolory[id], lwd=3)
      }
   }) 
dev.off()
